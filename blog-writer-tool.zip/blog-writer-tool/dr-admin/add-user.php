<?php
session_start();

if(!isset($_SESSION['admin_id'])){
    header("Location: admin-login.php");
    exit;
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';

include 'config.php';

$message = "";
$error = "";

if(isset($_POST['add_user'])){

    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $insert = mysqli_query(
        $conn,
        "INSERT INTO blog_writer_users
        (name,email,password)
        VALUES
        ('$name','$email','$password')"
    );

    if($insert){

        $mail = new PHPMailer(true);

        try {

            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;

$mail->Username = 'counsellor3.digitalreach@gmail.com';
$mail->Password = 'dtig pqkq vhbk lkcv';

$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
$mail->Port = 587;

$mail->setFrom(
    'counsellor3.digitalreach@gmail.com',
    'Digital Reach'
);

            $mail->addAddress($email, $name);

            $mail->isHTML(true);
            $mail->Subject = 'Your Blog Writer Tool Login Details';

            $mail->Body = "
                <h2>Welcome to Digital Reach</h2>
                <p>Hello <b>$name</b>,</p>
                <p>Your Blog Writer Tool account has been created successfully.</p>
                <p><b>Email:</b> $email</p>
                <p><b>Password:</b> $password</p>
                <p>Please use these credentials to login.</p>
                <br>
                <p>Regards,<br>Digital Reach Team</p>
            ";

            $mail->send();

            $message = "User Added Successfully & Password Sent by Email";

        } catch(Exception $e) {

            $message = "User Added Successfully";
            $error = "Email Failed: " . $mail->ErrorInfo;
        }

    }else{
        $error = "User could not be added";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Add User</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<style>
*{
  margin:0;
  padding:0;
  box-sizing:border-box;
}

body{
  font-family:'Poppins',sans-serif;
  background:#f5f6fa;
}

.admin-layout{
  display:flex;
  min-height:100vh;
}

.main-content{
  margin-left:280px;
  width:calc(100% - 280px);
  padding:30px;
}

.form-card{
  background:#fff;
  border-radius:24px;
  padding:24px;
  max-width:520px;
  box-shadow:0 10px 30px rgba(0,0,0,0.06);
}

.form-card h1{
  font-size:32px;
  color:#24324a;
  margin-bottom:25px;
}

.input-group{
  margin-bottom:22px;
}

.input-group label{
  display:block;
  margin-bottom:10px;
  font-size:14px;
  font-weight:600;
  color:#24324a;
}

.input-group input{
  width:100%;
  height:56px;
  border:1px solid #eee;
  border-radius:14px;
  padding:0 18px;
  font-size:15px;
  font-family:'Poppins',sans-serif;
  outline:none;
}

.submit-btn{
  width:100%;
  height:56px;
  border:none;
  border-radius:14px;
  background:#cf6d86;
  color:#fff;
  font-size:16px;
  font-weight:600;
  cursor:pointer;
}

.success-msg{
  background:#e8fff1;
  color:#0f9d58;
  padding:14px;
  border-radius:12px;
  margin-bottom:20px;
  font-size:14px;
}

.error-msg{
  background:#ffe7e7;
  color:#c62828;
  padding:14px;
  border-radius:12px;
  margin-bottom:20px;
  font-size:14px;
}

@media(max-width:991px){
  .main-content{
    margin-left:0;
    width:100%;
    padding:20px;
  }
}
</style>

</head>

<body>

<div class="admin-layout">

<?php include 'sidebar.php'; ?>

<div class="main-content">

<div class="form-card">

<h1>Add User</h1>

<?php if($message != ""){ ?>
<div class="success-msg">
<?php echo $message; ?>
</div>
<?php } ?>

<?php if($error != ""){ ?>
<div class="error-msg">
<?php echo $error; ?>
</div>
<?php } ?>

<form method="POST">

<div class="input-group">
<label>Name</label>
<input type="text" name="name" required>
</div>

<div class="input-group">
<label>Email</label>
<input type="email" name="email" required>
</div>

<div class="input-group">
<label>Password</label>
<input type="text" name="password" required>
</div>

<button type="submit" name="add_user" class="submit-btn">
Add User
</button>

</form>

</div>

</div>

</div>

</body>
</html>