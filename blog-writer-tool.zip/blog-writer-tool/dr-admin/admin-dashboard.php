<?php
session_start();

if(!isset($_SESSION['admin_id'])){
    header("Location: admin-login.php");
    exit;
}

include 'config.php';

$userName = $_SESSION['user_name'] ?? $_SESSION['admin_name'] ?? 'Admin';

/* COUNTS */

$totalUsersQuery = mysqli_query($conn, "SELECT COUNT(*) AS total FROM blog_writer_users");
$totalUsers = mysqli_fetch_assoc($totalUsersQuery)['total'] ?? 0;

$totalSearchQuery = mysqli_query($conn, "SELECT COUNT(*) AS total FROM blog_requests");
$totalSearches = mysqli_fetch_assoc($totalSearchQuery)['total'] ?? 0;

$totalGeneratedQuery = mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total FROM blog_requests WHERE ai_response IS NOT NULL AND ai_response != ''"
);
$totalGenerated = mysqli_fetch_assoc($totalGeneratedQuery)['total'] ?? 0;

/* GRAPH DATA - LAST 7 DAYS */

$labels = [];
$values = [];

for($i = 6; $i >= 0; $i--){
    $date = date('Y-m-d', strtotime("-$i days"));
    $labels[] = date('d M', strtotime($date));

    $q = mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total 
         FROM blog_requests 
         WHERE DATE(created_at) = '$date'"
    );

    $row = mysqli_fetch_assoc($q);
    $values[] = $row['total'] ?? 0;
}

/* RECENT SEARCHES - MAXIMUM 3 */

$recentQuery = mysqli_query(
    $conn,
    "SELECT id, user_name, university_name, topic, keyword1, created_at
     FROM blog_requests
     ORDER BY id DESC
     LIMIT 3"
);
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Admin Dashboard</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>

*{
  margin:0;
  padding:0;
  box-sizing:border-box;
}

body{
  font-family:'Poppins',sans-serif;
  background:#f5f6fa;
  overflow-x:hidden;
}

.admin-layout{
  display:flex;
  min-height:100vh;
}

.main-content{
  margin-left:280px;
  width:calc(100% - 280px);
  padding:30px;
}

.topbar{
  display:flex;
  align-items:center;
  justify-content:space-between;
  margin-bottom:35px;
}

.page-title h1{
  font-size:34px;
  font-weight:700;
  color:#24324a;
}

.page-title p{
  font-size:14px;
  color:#777;
  margin-top:6px;
}

.profile-dropdown{
  position:relative;
}

.profile-btn{
  width:55px;
  height:55px;
  border:none;
  border-radius:50%;
  background:#cf6d86;
  color:#fff;
  font-size:18px;
  font-weight:700;
  cursor:pointer;
  box-shadow:0 10px 25px rgba(0,0,0,0.1);
}

.profile-menu{
  position:absolute;
  top:70px;
  right:0;
  width:220px;
  background:#fff;
  border-radius:18px;
  padding:10px;
  box-shadow:0 20px 50px rgba(0,0,0,0.1);
  display:none;
  z-index:1200;
}

.profile-menu.show{
  display:block;
}

.profile-menu a{
  display:flex;
  align-items:center;
  gap:12px;
  padding:14px;
  text-decoration:none;
  color:#24324a;
  border-radius:12px;
  transition:0.3s;
  font-size:14px;
  font-weight:500;
}

.profile-menu a:hover{
  background:#f5f5f5;
  color:#cf6d86;
}

.stats-grid{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:25px;
  margin-bottom:35px;
}

.stat-card{
  background:#fff;
  border-radius:24px;
  padding:28px;
  box-shadow:0 10px 30px rgba(0,0,0,0.06);
}

.stat-icon{
  width:60px;
  height:60px;
  border-radius:18px;
  background:linear-gradient(to right,#cf6d86,#df88a0);
  display:flex;
  align-items:center;
  justify-content:center;
  color:#fff;
  font-size:24px;
  margin-bottom:18px;
}

.stat-card h3{
  font-size:16px;
  color:#777;
  margin-bottom:10px;
}

.stat-card h2{
  font-size:34px;
  font-weight:700;
  color:#24324a;
}

.dashboard-grid{
  display:grid;
  grid-template-columns:2fr 1fr;
  gap:25px;
}

.chart-card,
.recent-card{
  background:#fff;
  border-radius:24px;
  padding:28px;
  box-shadow:0 10px 30px rgba(0,0,0,0.06);
}

.card-header{
  display:flex;
  align-items:center;
  justify-content:space-between;
  margin-bottom:24px;
}

.card-header h2{
  font-size:24px;
  color:#24324a;
}

.view-link{
  text-decoration:none;
  color:#cf6d86;
  font-size:14px;
  font-weight:600;
}

.recent-item{
  padding:18px 0;
  border-bottom:1px solid #eee;
}

.recent-item:last-child{
  border-bottom:none;
}

.user-line{
  display:flex;
  align-items:center;
  gap:10px;
  margin-bottom:8px;
}

.user-avatar{
  width:34px;
  height:34px;
  border-radius:50%;
  background:#cf6d86;
  color:#fff;
  display:flex;
  align-items:center;
  justify-content:center;
  font-size:13px;
  font-weight:700;
}

.user-line strong{
  font-size:14px;
  color:#24324a;
}

.recent-item h4{
  font-size:15px;
  color:#24324a;
  margin-bottom:6px;
}

.recent-item p{
  font-size:13px;
  color:#777;
  line-height:1.6;
}

.time-line{
  display:flex;
  gap:8px;
  align-items:center;
  margin-top:8px;
  font-size:12px;
  color:#cf6d86;
  font-weight:600;
}

.no-data{
  font-size:14px;
  color:#777;
}

@media(max-width:991px){

  .main-content{
    margin-left:0;
    width:100%;
    padding:20px;
  }

  .stats-grid,
  .dashboard-grid{
    grid-template-columns:1fr;
  }
}

@media(max-width:576px){

  .page-title h1{
    font-size:26px;
  }

  .stat-card,
  .chart-card,
  .recent-card{
    padding:22px;
  }
}

</style>

</head>

<body>

<div class="admin-layout">

<?php include 'sidebar.php'; ?>

<main class="main-content">

<div class="topbar">

  <div style="display:flex;align-items:center;gap:15px;">

    <button class="menu-btn" onclick="openSidebar()">
      <i class="bi bi-list"></i>
    </button>

    <div class="page-title">
      <h1>Admin Dashboard</h1>
      <p>Track blog requests, searches, and AI content activity</p>
    </div>

  </div>

  <div class="profile-dropdown">

    <button class="profile-btn" onclick="toggleProfileMenu()">
      <?php echo strtoupper(substr($userName,0,1)); ?>
    </button>

    <div class="profile-menu" id="profileMenu">

      <a href="#">
        <i class="bi bi-person-circle"></i>
        Profile
      </a>

      <a href="logout.php">
        <i class="bi bi-box-arrow-right"></i>
        Logout
      </a>

    </div>

  </div>

</div>

<div class="stats-grid">

  <div class="stat-card">
    <div class="stat-icon">
      <i class="bi bi-people-fill"></i>
    </div>
    <h3>Total Users</h3>
    <h2><?php echo $totalUsers; ?></h2>
  </div>

  <div class="stat-card">
    <div class="stat-icon">
      <i class="bi bi-search"></i>
    </div>
    <h3>Total Searches</h3>
    <h2><?php echo $totalSearches; ?></h2>
  </div>

  <div class="stat-card">
    <div class="stat-icon">
      <i class="bi bi-file-earmark-text-fill"></i>
    </div>
    <h3>Generated Blogs</h3>
    <h2><?php echo $totalGenerated; ?></h2>
  </div>

</div>

<div class="dashboard-grid">

  <div class="chart-card">

    <div class="card-header">
      <h2>Search History Graph</h2>
      <a href="search-history.php" class="view-link">View Full History</a>
    </div>

    <canvas id="searchChart" height="120"></canvas>

  </div>

  <div class="recent-card">

    <div class="card-header">
      <h2>Recent Searches</h2>
    </div>

    <?php if(mysqli_num_rows($recentQuery) > 0){ ?>

      <?php while($row = mysqli_fetch_assoc($recentQuery)){ ?>

        <?php
          $searchedBy = $row['user_name'] ?: 'Unknown User';
          $createdAt = $row['created_at'] ?? '';
          $dateText = $createdAt ? date('d M Y', strtotime($createdAt)) : 'N/A';
          $timeText = $createdAt ? date('h:i A', strtotime($createdAt)) : 'N/A';
        ?>

        <div class="recent-item">

          <div class="user-line">
            <div class="user-avatar">
              <?php echo strtoupper(substr($searchedBy,0,1)); ?>
            </div>

            <strong>
              <?php echo htmlspecialchars($searchedBy); ?>
            </strong>
          </div>

          <h4>
            <?php echo htmlspecialchars($row['university_name'] ?: 'N/A'); ?>
          </h4>

          <p>
            <?php echo htmlspecialchars($row['topic'] ?: 'N/A'); ?><br>
            Keyword: <?php echo htmlspecialchars($row['keyword1'] ?: 'N/A'); ?>
          </p>

          <div class="time-line">
            <i class="bi bi-calendar-event"></i>
            <?php echo $dateText; ?>

            <i class="bi bi-clock"></i>
            <?php echo $timeText; ?>
          </div>

        </div>

      <?php } ?>

    <?php }else{ ?>

      <p class="no-data">No recent search history found.</p>

    <?php } ?>

  </div>

</div>

</main>

</div>

<script>

function toggleProfileMenu(){
  document.getElementById('profileMenu').classList.toggle('show');
}

window.onclick = function(e){
  if(!e.target.closest('.profile-dropdown')){
    document.getElementById('profileMenu').classList.remove('show');
  }
}

const ctx = document.getElementById('searchChart');

new Chart(ctx, {
    type: 'line',
    data: {
        labels: <?php echo json_encode($labels); ?>,
        datasets: [{
            label: 'Search Requests',
            data: <?php echo json_encode($values); ?>,
            borderColor: '#cf6d86',
            backgroundColor: 'rgba(207,109,134,0.12)',
            fill: true,
            tension: 0.4,
            pointRadius: 5,
            pointBackgroundColor: '#cf6d86'
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                display: true
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    precision: 0
                }
            }
        }
    }
});

</script>

</body>
</html>