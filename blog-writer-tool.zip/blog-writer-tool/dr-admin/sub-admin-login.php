<?php
session_start();

include 'config.php';

$error = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){

    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $query = mysqli_query(
        $conn,
        "SELECT * FROM blog_writer_sub_admin
         WHERE email='$email'
         AND password='$password'
         AND status='Active'
         LIMIT 1"
    );

    if(mysqli_num_rows($query) > 0){

        $subAdmin = mysqli_fetch_assoc($query);

        $_SESSION['admin_id'] = $subAdmin['id'];
        $_SESSION['admin_name'] = $subAdmin['name'];
        $_SESSION['admin_email'] = $subAdmin['email'];
        $_SESSION['admin_type'] = 'sub_admin';

        header("Location: admin-dashboard.php");
        exit;

    }else{
        $error = "Invalid email, password, or inactive account.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Sub Admin Login</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<style>
*{margin:0;padding:0;box-sizing:border-box;}

body{
  font-family:'Poppins',sans-serif;
  min-height:100vh;
  background:linear-gradient(135deg,#c96b86,#df88a0);
  display:flex;
  align-items:center;
  justify-content:center;
  padding:20px;
}

.login-card{
  width:100%;
  max-width:400px;
  background:#fff;
  border-radius:24px;
  padding:30px;
  box-shadow:0 20px 60px rgba(0,0,0,0.12);
}

.login-card h1{
  font-size:28px;
  color:#24324a;
  margin-bottom:10px;
  text-align:center;
}

.login-card p{
  font-size:14px;
  color:#666;
  text-align:center;
  margin-bottom:24px;
}

.input-group{
  margin-bottom:18px;
}

.input-group label{
  display:block;
  margin-bottom:8px;
  color:#24324a;
  font-size:14px;
  font-weight:600;
}

.input-group input{
  width:100%;
  height:52px;
  border:1px solid #eee;
  border-radius:14px;
  padding:0 16px;
  font-size:14px;
  outline:none;
  font-family:'Poppins',sans-serif;
}

.login-btn{
  width:100%;
  height:52px;
  border:none;
  border-radius:14px;
  background:#cf6d86;
  color:#fff;
  font-size:15px;
  font-weight:600;
  cursor:pointer;
  font-family:'Poppins',sans-serif;
}

.error-msg{
  background:#ffe7e7;
  color:#c62828;
  padding:12px;
  border-radius:10px;
  margin-bottom:16px;
  font-size:14px;
}
</style>
</head>

<body>

<div class="login-card">

<h1>Sub Admin Login</h1>

<p>Login to access the admin dashboard.</p>

<?php if($error != ""){ ?>
<div class="error-msg">
<?php echo $error; ?>
</div>
<?php } ?>

<form method="POST">

<div class="input-group">
<label>Email</label>
<input type="email" name="email" placeholder="Enter email" required>
</div>

<div class="input-group">
<label>Password</label>
<input type="password" name="password" placeholder="Enter password" required>
</div>

<button type="submit" class="login-btn">
Login to Dashboard
</button>

</form>

</div>

</body>
</html>