<?php

session_start();

/* =========================
   UNSET ADMIN SESSION
========================= */

unset($_SESSION['admin_id']);

unset($_SESSION['admin_name']);

/* =========================
   DESTROY SESSION
========================= */

session_destroy();

/* =========================
   REDIRECT TO LOGIN
========================= */

header("Location: admin-login.php");

exit;

?>