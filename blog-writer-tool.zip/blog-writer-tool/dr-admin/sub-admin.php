<?php
session_start();

if(
    !isset($_SESSION['admin_id']) ||
    ($_SESSION['admin_type'] ?? '') == 'sub_admin'
){
    header("Location: admin-dashboard.php");
    exit;
}

include 'config.php';

$conn = new mysqli($host, $user, $pass, $db);

if($conn->connect_error){
    die("Database Connection Failed");
}

$message = "";
$error = "";

if(isset($_POST['add_sub_admin'])){

    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $check = mysqli_query(
        $conn,
        "SELECT id FROM blog_writer_sub_admin WHERE email='$email'"
    );

    if(mysqli_num_rows($check) > 0){

        $error = "This email already exists.";

    }else{

        $insert = mysqli_query(
            $conn,
            "INSERT INTO blog_writer_sub_admin
            (name, email, password, status)
            VALUES
            ('$name', '$email', '$password', 'Active')"
        );

        if($insert){
            $message = "Sub Admin Added Successfully";
        }else{
            $error = "Sub Admin could not be added.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Sub Admin Login Details</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<style>

*{
  margin:0;
  padding:0;
  box-sizing:border-box;
}

body{
  font-family:'Poppins',sans-serif;
  background:#f5f6fa;
  overflow-x:hidden;
}

.admin-layout{
  display:flex;
  min-height:100vh;
}

.main-content{
  margin-left:280px;
  width:calc(100% - 280px);
  padding:30px;
}

.page-header{
  display:flex;
  align-items:center;
  justify-content:space-between;
  margin-bottom:30px;
}

.page-header h1{
  font-size:32px;
  color:#24324a;
}

.form-card,
.table-card{
  background:#fff;
  border-radius:24px;
  padding:25px;
  box-shadow:0 10px 30px rgba(0,0,0,0.06);
  margin-bottom:25px;
}

.form-card h2{
  font-size:24px;
  color:#24324a;
  margin-bottom:22px;
}

.grid3{
  display:grid;
  grid-template-columns:1fr 1fr 1fr;
  gap:18px;
}

.input-group{
  margin-bottom:18px;
}

.input-group label{
  display:block;
  margin-bottom:10px;
  font-size:14px;
  font-weight:600;
  color:#24324a;
}

.input-group input{
  width:100%;
  height:54px;
  border:1px solid #eee;
  border-radius:14px;
  padding:0 18px;
  font-size:15px;
  font-family:'Poppins',sans-serif;
  outline:none;
}

.submit-btn{
  min-width:180px;
  height:52px;
  border:none;
  border-radius:14px;
  background:#cf6d86;
  color:#fff;
  font-size:15px;
  font-weight:600;
  font-family:'Poppins',sans-serif;
  cursor:pointer;
  padding:0 28px;
}

.success-msg{
  background:#e8fff1;
  color:#0f9d58;
  padding:14px;
  border-radius:12px;
  margin-bottom:20px;
  font-size:14px;
}

.error-msg{
  background:#ffe7e7;
  color:#c62828;
  padding:14px;
  border-radius:12px;
  margin-bottom:20px;
  font-size:14px;
}

.table-wrap{
  overflow-x:auto;
}

.table-wrap table{
  width:100%;
  border-collapse:collapse;
}

.table-wrap th,
.table-wrap td{
  padding:16px;
  border-bottom:1px solid #eee;
  text-align:left;
  font-size:14px;
}

.table-wrap th{
  color:#24324a;
  font-weight:600;
}

.table-wrap td{
  color:#666;
}

.status-active{
  color:#0f9d58;
  font-weight:600;
}

.status-inactive{
  color:#c62828;
  font-weight:600;
}

@media(max-width:991px){

  .main-content{
    margin-left:0;
    width:100%;
    padding:20px;
  }

  .grid3{
    grid-template-columns:1fr;
  }
}

@media(max-width:768px){

  .page-header{
    flex-direction:column;
    align-items:flex-start;
    gap:15px;
  }

  .page-header h1{
    font-size:26px;
  }
}

</style>

</head>

<body>

<div class="admin-layout">

<?php include 'sidebar.php'; ?>

<main class="main-content">

<div class="page-header">

<div style="display:flex;align-items:center;gap:15px;">

<button class="menu-btn" onclick="openSidebar()">
<i class="bi bi-list"></i>
</button>

<h1>Sub Admin Login Details</h1>

</div>

</div>

<div class="form-card">

<h2>Add Sub Admin</h2>

<?php if($message != ""){ ?>
<div class="success-msg">
<?php echo $message; ?>
</div>
<?php } ?>

<?php if($error != ""){ ?>
<div class="error-msg">
<?php echo $error; ?>
</div>
<?php } ?>

<form method="POST">

<div class="grid3">

<div class="input-group">
<label>Name</label>
<input type="text" name="name" required>
</div>

<div class="input-group">
<label>Email</label>
<input type="email" name="email" required>
</div>

<div class="input-group">
<label>Password</label>
<input type="text" name="password" required>
</div>

</div>

<div style="display:flex;justify-content:flex-start;">

<button
type="submit"
name="add_sub_admin"
class="submit-btn"
>
Add Sub Admin
</button>

</div>

</form>

</div>

<div class="table-card">

<div class="table-wrap">

<table>

<thead>

<tr>
<th>ID</th>
<th>Name</th>
<th>Email</th>
<th>Password</th>
<th>Status</th>
<th>Created At</th>
</tr>

</thead>

<tbody>

<?php

$query = mysqli_query(
    $conn,
    "SELECT * FROM blog_writer_sub_admin ORDER BY id DESC"
);

while($row = mysqli_fetch_assoc($query)){
?>

<tr>

<td><?php echo htmlspecialchars($row['id']); ?></td>

<td><?php echo htmlspecialchars($row['name']); ?></td>

<td><?php echo htmlspecialchars($row['email']); ?></td>

<td><?php echo htmlspecialchars($row['password']); ?></td>

<td>

<?php if(($row['status'] ?? '') == 'Inactive'){ ?>

<span class="status-inactive">
Inactive
</span>

<?php }else{ ?>

<span class="status-active">
Active
</span>

<?php } ?>

</td>

<td><?php echo htmlspecialchars($row['created_at'] ?? ''); ?></td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

</main>

</div>

</body>
</html>