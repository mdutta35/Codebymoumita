<?php

session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';

include 'config.php';

$message = "";

if(isset($_POST['send_code'])){

    $email = mysqli_real_escape_string($conn, $_POST['email']);

    $query = mysqli_query(
        $conn,
        "SELECT * FROM blog_writer_admin_login WHERE email='$email'"
    );

    if(mysqli_num_rows($query) > 0){

        $code = rand(100000,999999);

        $_SESSION['reset_code'] = $code;
        $_SESSION['reset_email'] = $email;

        $mail = new PHPMailer(true);

        try {

            $mail->isSMTP();

            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;

            $mail->Username = 'counsellor3.digitalreach@gmail.com';
            $mail->Password = 'dtig pqkq vhbk lkcv';

            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            $mail->setFrom(
                'counsellor3.digitalreach@gmail.com',
                'Digital Reach'
            );

            $mail->addAddress($email);

            $mail->isHTML(true);

            $mail->Subject = 'Password Reset Verification Code';

            $mail->Body = "
                <h2>Password Reset</h2>
                <p>Your verification code is:</p>
                <h1>$code</h1>
                <p>Digital Reach Admin Panel</p>
            ";

            $mail->send();

            header("Location: verify-code.php");
            exit;

        } catch (Exception $e) {

            $message = 'Email could not be sent: ' . $mail->ErrorInfo;
        }

    }else{

        $message = "Email not found";
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Forgot Password</title>

<link rel="preconnect" href="https://fonts.googleapis.com">

<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<style>

*{
  margin:0;
  padding:0;
  box-sizing:border-box;
}

body{
  font-family:'Poppins',sans-serif;
  min-height:100vh;
  background:linear-gradient(135deg,#c96b86,#df88a0);
  display:flex;
  align-items:center;
  justify-content:center;
  padding:20px;
}

.form-card{
  width:100%;
  max-width:420px;
  background:#fff;
  border-radius:24px;
  padding:30px;
}

.form-card h1{
  font-size:28px;
  margin-bottom:10px;
  color:#24324a;
}

.form-card p{
  font-size:14px;
  color:#666;
  margin-bottom:20px;
}

.input-group{
  margin-bottom:18px;
}

.input-group input{
  width:100%;
  height:48px;
  border:1px solid #eee;
  border-radius:12px;
  padding:0 16px;
  font-size:14px;
  outline:none;
}

.submit-btn{
  width:100%;
  height:48px;
  border:none;
  border-radius:12px;
  background:#cf6d86;
  color:#fff;
  font-size:15px;
  font-weight:600;
  cursor:pointer;
}

.error-msg{
  background:#ffe7e7;
  color:#c62828;
  padding:12px;
  border-radius:10px;
  margin-bottom:16px;
  font-size:14px;
}

</style>

</head>

<body>

<div class="form-card">

<h1>Forgot Password</h1>

<p>
Enter your admin email to receive verification code.
</p>

<?php if($message != ""){ ?>

<div class="error-msg">

<?php echo $message; ?>

</div>

<?php } ?>

<form method="POST">

<div class="input-group">

<input
type="email"
name="email"
placeholder="Enter Email"
required
>

</div>

<button
type="submit"
name="send_code"
class="submit-btn"
>

Send Verification Code

</button>

</form>

</div>

</body>

</html>