<?php

/* =========================
   DATABASE CONFIG
========================= */

$host = "localhost";

$db = "university_blog_writer";

$user = "root";

$pass = "";

/* =========================
   CONNECTION
========================= */

$conn = new mysqli($host, $user, $pass, $db);

if($conn->connect_error){

    die(
        "Database Connection Failed: " .
        $conn->connect_error
    );
}

?>