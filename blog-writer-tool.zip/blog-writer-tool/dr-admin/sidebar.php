<?php
$adminName = $_SESSION['user_name'] ?? $_SESSION['admin_name'] ?? 'Admin';

$currentPage = basename($_SERVER['PHP_SELF']);
?>

<style>

/* SIDEBAR */

.sidebar{
  width:280px;
  background:linear-gradient(180deg,#c96b86,#df88a0);
  padding:30px 20px;
  position:fixed;
  top:0;
  left:0;
  height:100vh;
  overflow-y:auto;
  transition:0.3s;
  z-index:1000;
}

.logo-box{
  display:flex;
  align-items:center;
  gap:14px;
  margin-bottom:45px;
}

.logo-circle{
  width:58px;
  height:58px;
  border-radius:50%;
  background:#fff;
  display:flex;
  align-items:center;
  justify-content:center;
}

.logo-circle img{
  width:38px;
}

.logo-text h2{
  font-size:20px;
  font-weight:700;
  color:#fff;
}

.sidebar-menu{
  display:flex;
  flex-direction:column;
  gap:14px;
}

.sidebar-menu a{
  display:flex;
  align-items:center;
  gap:14px;
  text-decoration:none;
  background:rgba(255,255,255,0.12);
  color:#fff;
  padding:16px 18px;
  border-radius:16px;
  font-size:15px;
  font-weight:500;
  transition:0.3s;
}

.sidebar-menu a i{
  font-size:18px;
}

.sidebar-menu a:hover,
.sidebar-menu a.active{
  background:#fff;
  color:#cf6d86;
}

.menu-btn{
  display:none;
  width:48px;
  height:48px;
  border:none;
  border-radius:12px;
  background:#cf6d86;
  color:#fff;
  font-size:22px;
  cursor:pointer;
}

.sidebar-overlay{
  display:none;
}

@media(max-width:991px){

  .sidebar{
    left:-100%;
  }

  .sidebar.show{
    left:0;
  }

  .sidebar-overlay{
    display:block;
    position:fixed;
    top:0;
    left:0;
    width:100%;
    height:100vh;
    background:rgba(0,0,0,0.4);
    z-index:999;
    opacity:0;
    visibility:hidden;
    transition:0.3s;
  }

  .sidebar-overlay.show{
    opacity:1;
    visibility:visible;
  }

  .menu-btn{
    display:block;
  }
}

</style>

<div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSidebar()"></div>

<aside class="sidebar" id="sidebar">

  <div class="logo-box">

    <div class="logo-circle">
      <img src="../images/DR logo-Transparent.png" alt="Logo">
    </div>

    <div class="logo-text">
      <h2>Admin Panel</h2>
    </div>

  </div>

  <div class="sidebar-menu">

    <a href="admin-dashboard.php" class="<?php echo ($currentPage == 'admin-dashboard.php') ? 'active' : ''; ?>">
      <i class="bi bi-grid-fill"></i>
      Admin Dashboard
    </a>

    <?php if(($_SESSION['admin_type'] ?? '') != 'sub_admin'){ ?>

<a href="sub-admin.php" class="<?php echo ($currentPage == 'sub-admin.php') ? 'active' : ''; ?>">
  <i class="bi bi-person-gear"></i>
  Sub Admin
</a>

<?php } ?>

    <a href="users-login-details.php" class="<?php echo ($currentPage == 'users-login-details.php') ? 'active' : ''; ?>">
      <i class="bi bi-people-fill"></i>
      Users Login Details
    </a>


    <a href="user-login-history.php" class="<?php echo ($currentPage == 'user-login-history.php') ? 'active' : ''; ?>">
  <i class="bi bi-clock-history"></i>
  User Login History
</a>


    <a href="search-history.php" class="<?php echo ($currentPage == 'search-history.php') ? 'active' : ''; ?>">
  <i class="bi bi-clock-history"></i>
  Search History
</a>

<a href="add-user.php" class="<?php echo ($currentPage == 'add-user.php') ? 'active' : ''; ?>">
  <i class="bi bi-person-plus-fill"></i>
  Add User
</a>

<a href="logout.php">
  <i class="bi bi-box-arrow-right"></i>
  Logout
</a>

  </div>

</aside>

<script>

function openSidebar(){
  document.getElementById('sidebar').classList.add('show');
  document.getElementById('sidebarOverlay').classList.add('show');
}

function closeSidebar(){
  document.getElementById('sidebar').classList.remove('show');
  document.getElementById('sidebarOverlay').classList.remove('show');
}

</script>