<?php

session_start();

/* =========================
   DATABASE CONNECTION
========================= */

include 'config.php';

/* CONNECTION */

$conn = new mysqli($host, $user, $pass, $db);

if($conn->connect_error){

    die(
        "Database Connection Failed: " .
        $conn->connect_error
    );
}

/* =========================
   LOGIN LOGIC
========================= */

$error = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){

    $email = trim($_POST['email']);

    $password = trim($_POST['password']);

    /* =========================
       CHECK ADMIN LOGIN
    ========================= */

    $stmt = $conn->prepare("
        SELECT *
        FROM blog_writer_admin_login
        WHERE email = ?
        LIMIT 1
    ");

    if(!$stmt){

        die(
            "SQL Error: " .
            $conn->error
        );
    }

    $stmt->bind_param("s", $email);

    $stmt->execute();

    $result = $stmt->get_result();

    if($result->num_rows > 0){

        $admin = $result->fetch_assoc();

        /* =========================
           PASSWORD CHECK
        ========================= */

        if($password == $admin['password']){

            $_SESSION['admin_id'] = $admin['id'];

            $_SESSION['admin_name'] = $admin['name'];

            $_SESSION['admin_email'] = $admin['email'];

            header("Location: admin-dashboard.php");

            exit;

        }else{

            $error = "Invalid password.";
        }

    }else{

        $error = "Email not found.";
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Admin Login</title>

<!-- Poppins Font -->

<link rel="preconnect" href="https://fonts.googleapis.com">

<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<!-- Bootstrap Icons -->

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<style>

/* =========================
   GLOBAL
========================= */

*{
  margin:0;
  padding:0;
  box-sizing:border-box;
}

body{
  font-family:'Poppins',sans-serif;
  min-height:100vh;
  background:linear-gradient(135deg,#c96b86,#df88a0);
  display:flex;
  align-items:center;
  justify-content:center;
  overflow:hidden;
  position:relative;
  padding:20px;
}

/* BACKGROUND */

body::before{
  content:"";
  position:absolute;
  width:700px;
  height:700px;
  background:rgba(255,255,255,0.08);
  border-radius:50%;
  top:-250px;
  left:-200px;
}

body::after{
  content:"";
  position:absolute;
  width:800px;
  height:800px;
  background:rgba(255,255,255,0.05);
  border-radius:50%;
  bottom:-350px;
  right:-250px;
}

/* =========================
   LOGIN CARD
========================= */

.login-card{
  width:100%;
  max-width:390px;
  background:rgba(255,255,255,0.96);
  border-radius:24px;
  padding:28px 24px;
  position:relative;
  z-index:2;
  box-shadow:0 20px 60px rgba(0,0,0,0.12);
}

/* =========================
   LOGO
========================= */

.logo-box{
  width:78px;
  height:78px;
  border-radius:50%;
  background:#fff;
  display:flex;
  align-items:center;
  justify-content:center;
  margin:0 auto 18px;
  box-shadow:0 10px 30px rgba(0,0,0,0.1);
}

.logo-box img{
  width:50px;
  object-fit:contain;
}

/* =========================
   TEXT
========================= */

.login-card h1{
  text-align:center;
  font-size:28px;
  font-weight:700;
  color:#24324a;
  margin-bottom:8px;
}

.login-text{
  text-align:center;
  font-size:14px;
  color:#666;
  line-height:1.5;
  margin-bottom:22px;
}

/* =========================
   ERROR
========================= */

.error-box{
  background:#ffe7e7;
  color:#c62828;
  padding:12px;
  border-radius:10px;
  font-size:13px;
  margin-bottom:18px;
}

/* =========================
   INPUT
========================= */

.input-group{
  margin-bottom:14px;
}

.input-group label{
  display:block;
  margin-bottom:8px;
  font-size:13px;
  font-weight:500;
  color:#24324a;
}

.input-wrap{
  position:relative;
}

.input-wrap i{
  position:absolute;
  left:14px;
  top:50%;
  transform:translateY(-50%);
  color:#999;
  font-size:15px;
}

.input-wrap input{
  width:100%;
  height:46px;
  border:1px solid #e5e5e5;
  border-radius:12px;
  padding:0 16px 0 42px;
  font-size:14px;
  font-family:'Poppins',sans-serif;
  outline:none;
  transition:0.3s;
}

.input-wrap input:focus{
  border-color:#cf6d86;
}

/* =========================
   BUTTON
========================= */

.login-btn{
  width:100%;
  height:46px;
  border:none;
  border-radius:12px;
  background:linear-gradient(to right,#cf6d86,#df88a0);
  color:#fff;
  font-size:15px;
  font-weight:600;
  font-family:'Poppins',sans-serif;
  cursor:pointer;
  transition:0.3s;
  margin-top:4px;
}

.login-btn:hover{
  transform:translateY(-2px);
}

/* =========================
   FOOTER TEXT
========================= */

.bottom-text{
  text-align:center;
  margin-top:16px;
  font-size:13px;
  color:#777;
}

/* =========================
   MOBILE
========================= */

@media(max-width:576px){

  .login-card{
    padding:24px 18px;
    border-radius:22px;
  }

  .logo-box{
    width:72px;
    height:72px;
  }

  .logo-box img{
    width:45px;
  }

  .login-card h1{
    font-size:24px;
  }

  .login-text{
    font-size:13px;
  }

  .input-wrap input{
    height:44px;
  }

  .login-btn{
    height:44px;
    font-size:14px;
  }
}
</style>

</head>

<body>

<div class="login-card">

  <!-- LOGO -->

  <div class="logo-box">

    <img src="../images/DR logo-Transparent.png" alt="Logo">

  </div>

  <!-- TITLE -->

  <h1>Admin Login</h1>

  <p class="login-text">
    Welcome back! Please login to access the admin dashboard.
  </p>

  <!-- ERROR -->

  <?php if($error != ""){ ?>

    <div class="error-box">

      <?php echo $error; ?>

    </div>

  <?php } ?>

  <!-- FORM -->

  <form method="POST" autocomplete="off">

    <!-- EMAIL -->

    <div class="input-group">

      <label>Email Address</label>

      <div class="input-wrap">

        <i class="bi bi-envelope-fill"></i>

        <input
          type="email"
          name="email"
          placeholder="Enter your email"
          required
        >

      </div>

    </div>

    <!-- PASSWORD -->

    <div class="input-group">

      <label>Password</label>

      <div class="input-wrap">

        <i class="bi bi-lock-fill"></i>

        <input
          type="password"
          name="password"
          placeholder="Enter your password"
          required
        >

      </div>

    </div>

    <!-- BUTTON -->

    <button
      type="submit"
      class="login-btn"
    >
      Login to Admin Panel
    </button>

  </form>

  <p class="bottom-text">

  <a
  href="forgot-password.php"
  style="
  color:#cf6d86;
  text-decoration:none;
  font-weight:500;
  "
  >

  Forget Password?

  </a>

</p>

</div>

</body>

</html>