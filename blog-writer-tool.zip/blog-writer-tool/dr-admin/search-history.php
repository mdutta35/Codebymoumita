<?php
session_start();

if(!isset($_SESSION['admin_id'])){
    header("Location: admin-login.php");
    exit;
}

include 'config.php';

$limit = 5;

$page = isset($_GET['page']) ? intval($_GET['page']) : 1;

if($page < 1){
    $page = 1;
}

$offset = ($page - 1) * $limit;

$totalQuery = mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total FROM blog_writer_user_login_history"
);

$totalData = mysqli_fetch_assoc($totalQuery);

$totalRows = $totalData['total'];

$totalPages = ceil($totalRows / $limit);

$limit = 5;

$page = isset($_GET['page']) ? intval($_GET['page']) : 1;

if($page < 1){
    $page = 1;
}

$offset = ($page - 1) * $limit;

$totalQuery = mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total FROM blog_writer_user_login_history"
);

$totalData = mysqli_fetch_assoc($totalQuery);

$totalRows = $totalData['total'];

$totalPages = ceil($totalRows / $limit);

$query = mysqli_query(
    $conn,
    "SELECT * FROM blog_writer_user_login_history
     ORDER BY id DESC
     LIMIT $offset, $limit"
);
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Search By Prompts</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<style>
*{margin:0;padding:0;box-sizing:border-box;}

body{
  font-family:'Poppins',sans-serif;
  background:#f5f6fa;
}

.admin-layout{
  display:flex;
  min-height:100vh;
}

.main-content{
  margin-left:280px;
  width:calc(100% - 280px);
  padding:22px;
}

.page-header{
  margin-bottom:22px;
}

.page-header h1{
  font-size:26px;
  font-weight:800;
  color:#24324a;
}

.history-grid{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:16px;
  margin-bottom:28px;
}

.history-card{
  background:#fff;
  border-radius:18px;
  padding:18px;
  min-height:110px;
  text-decoration:none;
  box-shadow:0 8px 25px rgba(0,0,0,0.05);
  transition:0.3s;
  display:flex;
  flex-direction:column;
  justify-content:center;
}

.history-card:hover{
  transform:translateY(-3px);
  box-shadow:0 12px 30px rgba(0,0,0,0.08);
}

.icon-box{
  width:46px;
  height:46px;
  border-radius:14px;
  background:#cf6d86;
  display:flex;
  align-items:center;
  justify-content:center;
  color:#fff;
  font-size:18px;
  margin-bottom:12px;
}

.history-card h2{
  font-size:17px;
  line-height:1.35;
  color:#24324a;
  font-weight:700;
}

.table-card{
  background:#fff;
  border-radius:20px;
  padding:20px;
  box-shadow:0 8px 25px rgba(0,0,0,0.05);
}

.table-header{
  margin-bottom:18px;
}

.table-header h2{
  font-size:20px;
  color:#24324a;
  font-weight:700;
}

.table-wrap{
  overflow-x:auto;
}

table{
  width:100%;
  border-collapse:collapse;
  min-width:1100px;
}

table th{
  background:#f8f8fb;
  color:#24324a;
  padding:14px;
  font-size:14px;
  text-align:left;
  font-weight:700;
  border-bottom:1px solid #eee;
}

table td{
  padding:14px;
  font-size:13px;
  color:#666;
  border-bottom:1px solid #f1f1f1;
}

.status-active{
  color:#16a34a;
  font-weight:600;
}

.status-online{
  color:#2563eb;
  font-weight:600;
}

.prompt-badge{
  display:inline-block;
  background:#fff1f5;
  color:#cf6d86;
  padding:7px 12px;
  border-radius:50px;
  font-size:12px;
  font-weight:600;
}

.count-badge{
  display:inline-flex;
  width:32px;
  height:32px;
  align-items:center;
  justify-content:center;
  background:#cf6d86;
  color:#fff;
  border-radius:50%;
  font-size:13px;
  font-weight:700;
}

@media(max-width:1100px){
  .history-grid{
    grid-template-columns:repeat(2,1fr);
  }
}

@media(max-width:991px){
  .main-content{
    margin-left:0;
    width:100%;
    padding:18px;
  }

  .history-grid{
    grid-template-columns:1fr;
    gap:14px;
  }

  .page-header h1{
    font-size:22px;
  }
}
</style>

</head>

<body>

<div class="admin-layout">

<?php include 'sidebar.php'; ?>

<main class="main-content">

<div class="page-header">
<h1>Search By Prompts</h1>
</div>

<div class="history-grid">

<a href="university-search-history.php" class="history-card">
<div class="icon-box"><i class="bi bi-pencil-square"></i></div>
<h2>AI-Powered Blog Writing Tool</h2>
</a>

<a href="admission-campaign-history.php" class="history-card">
<div class="icon-box"><i class="bi bi-mortarboard"></i></div>
<h2>Admission Campaign</h2>
</a>

<a href="seo-content-history.php" class="history-card">
<div class="icon-box"><i class="bi bi-graph-up-arrow"></i></div>
<h2>SEO Content</h2>
</a>

<a href="geo-llm-history.php" class="history-card">
<div class="icon-box"><i class="bi bi-robot"></i></div>
<h2>GEO + LLM</h2>
</a>

<a href="social-media-history.php" class="history-card">
<div class="icon-box"><i class="bi bi-megaphone"></i></div>
<h2>Social Media</h2>
</a>

<a href="brand-positioning-history.php" class="history-card">
<div class="icon-box"><i class="bi bi-award"></i></div>
<h2>Brand Positioning</h2>
</a>

</div>

<div class="table-card">

<div class="table-header">
<h2>User Prompt Activity</h2>
</div>

<div class="table-wrap">

<table>

<thead>
<tr>
<th>ID</th>
<th>User Name</th>
<th>Email</th>
<th>Prompt Name</th>
<th>Prompt Count</th>
<th>Login Time</th>
<th>Logout Time</th>
<th>Duration</th>
<th>Status</th>
</tr>
</thead>

<tbody>

<?php while($row = mysqli_fetch_assoc($query)){ ?>

<tr>

<td><?php echo htmlspecialchars($row['id']); ?></td>

<td><?php echo htmlspecialchars($row['user_name']); ?></td>

<td><?php echo htmlspecialchars($row['user_email']); ?></td>

<td>
<span class="prompt-badge">
<?php echo !empty($row['prompt_name']) ? htmlspecialchars($row['prompt_name']) : 'No Prompt Used'; ?>
</span>
</td>

<td>
<span class="count-badge">
<?php echo intval($row['prompt_count']); ?>
</span>
</td>

<td><?php echo htmlspecialchars($row['login_time']); ?></td>

<td>
<?php
if(!empty($row['logout_time'])){
    echo htmlspecialchars($row['logout_time']);
}else{
    echo '<span class="status-online">Online</span>';
}
?>
</td>

<td>
<?php echo gmdate("H:i:s", intval($row['duration_seconds'])); ?>
</td>

<td>
<?php
if(!empty($row['logout_time'])){
    echo '<span class="status-active">Logged Out</span>';
}else{
    echo '<span class="status-online">Active</span>';
}
?>
</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

</main>

</div>

</body>
</html>