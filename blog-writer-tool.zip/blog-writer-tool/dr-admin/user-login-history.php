<?php
session_start();

if(!isset($_SESSION['admin_id'])){
    header("Location: admin-login.php");
    exit;
}

include 'config.php';

$conn = new mysqli($host, $user, $pass, $db);

if($conn->connect_error){
    die("Database Connection Failed");
}

$query = mysqli_query(
    $conn,
    "SELECT * FROM blog_writer_user_login_history ORDER BY id DESC"
);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>User Login History</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<style>
*{
  margin:0;
  padding:0;
  box-sizing:border-box;
}

body{
  font-family:'Poppins',sans-serif;
  background:#f5f6fa;
  overflow-x:hidden;
}

.admin-layout{
  display:flex;
  min-height:100vh;
}

.main-content{
  margin-left:280px;
  width:calc(100% - 280px);
  padding:30px;
}

.page-header{
  display:flex;
  align-items:center;
  justify-content:space-between;
  margin-bottom:30px;
}

.page-header h1{
  font-size:32px;
  color:#24324a;
}

.table-card{
  background:#fff;
  border-radius:24px;
  padding:25px;
  box-shadow:0 10px 30px rgba(0,0,0,0.06);
}

.table-wrap{
  overflow-x:auto;
}

table{
  width:100%;
  border-collapse:collapse;
  min-width:1000px;
}

th,
td{
  padding:16px;
  border-bottom:1px solid #eee;
  text-align:left;
  font-size:14px;
}

th{
  color:#24324a;
  font-weight:600;
  background:#fafafa;
}

td{
  color:#666;
}

.duration-badge{
  background:#e8fff1;
  color:#0f9d58;
  padding:7px 12px;
  border-radius:20px;
  font-size:12px;
  font-weight:600;
}

.active-badge{
  background:#fff4df;
  color:#c47a00;
  padding:7px 12px;
  border-radius:20px;
  font-size:12px;
  font-weight:600;
}

@media(max-width:991px){
  .main-content{
    margin-left:0;
    width:100%;
    padding:20px;
  }
}

@media(max-width:768px){
  .page-header{
    flex-direction:column;
    align-items:flex-start;
    gap:15px;
  }

  .page-header h1{
    font-size:26px;
  }
}
</style>
</head>

<body>

<div class="admin-layout">

<?php include 'sidebar.php'; ?>

<main class="main-content">

<div class="page-header">

  <div style="display:flex;align-items:center;gap:15px;">

    <button class="menu-btn" onclick="openSidebar()">
      <i class="bi bi-list"></i>
    </button>

    <h1>User Login History</h1>

  </div>

</div>

<div class="table-card">

<div class="table-wrap">

<table>

<thead>
<tr>
  <th>ID</th>
  <th>User ID</th>
  <th>User Name</th>
  <th>User Email</th>
  <th>Login Time</th>
  <th>Logout Time</th>
  <th>Duration</th>
  <th>Created At</th>
</tr>
</thead>

<tbody>

<?php while($row = mysqli_fetch_assoc($query)){ ?>

<?php
$durationSeconds = intval($row['duration_seconds'] ?? 0);

if($durationSeconds > 0){
    $hours = floor($durationSeconds / 3600);
    $minutes = floor(($durationSeconds % 3600) / 60);
    $seconds = $durationSeconds % 60;

    $durationText = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);
}else{
    $durationText = "Still Logged In";
}
?>

<tr>
  <td><?php echo htmlspecialchars($row['id']); ?></td>

  <td><?php echo htmlspecialchars($row['user_id']); ?></td>

  <td><?php echo htmlspecialchars($row['user_name']); ?></td>

  <td><?php echo htmlspecialchars($row['user_email']); ?></td>

  <td><?php echo htmlspecialchars($row['login_time']); ?></td>

  <td>
    <?php echo $row['logout_time'] ? htmlspecialchars($row['logout_time']) : 'Not logged out'; ?>
  </td>

  <td>
    <?php if($durationSeconds > 0){ ?>
      <span class="duration-badge"><?php echo $durationText; ?></span>
    <?php }else{ ?>
      <span class="active-badge"><?php echo $durationText; ?></span>
    <?php } ?>
  </td>

  <td><?php echo htmlspecialchars($row['created_at']); ?></td>
</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

</main>

</div>

</body>
</html>