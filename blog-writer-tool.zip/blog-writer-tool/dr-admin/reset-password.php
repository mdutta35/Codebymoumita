<?php
session_start();

include 'config.php';

if(
    !isset($_SESSION['reset_email']) ||
    !isset($_SESSION['code_verified']) ||
    $_SESSION['code_verified'] !== true
){
    header("Location: forgot-password.php");
    exit;
}

$message = "";

if(isset($_POST['reset_password'])){

    $newPassword = mysqli_real_escape_string($conn, $_POST['new_password']);
    $email = mysqli_real_escape_string($conn, $_SESSION['reset_email']);

    mysqli_query(
        $conn,
        "UPDATE blog_writer_admin_login 
         SET password='$newPassword' 
         WHERE email='$email'"
    );

    unset($_SESSION['reset_code']);
    unset($_SESSION['reset_email']);
    unset($_SESSION['code_verified']);

    header("Location: admin-login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Reset Password</title>
<style>
body{
  font-family:Poppins, sans-serif;
  min-height:100vh;
  display:flex;
  align-items:center;
  justify-content:center;
  background:linear-gradient(135deg,#c96b86,#df88a0);
}
.form-card{
  width:100%;
  max-width:400px;
  background:#fff;
  border-radius:24px;
  padding:30px;
}
input,button{
  width:100%;
  height:48px;
  border-radius:12px;
  margin-bottom:18px;
}
input{
  border:1px solid #eee;
  padding:0 16px;
}
button{
  border:none;
  background:#cf6d86;
  color:#fff;
}
</style>
</head>

<body>
<div class="form-card">
<h2>Reset Password</h2>

<form method="POST">
<input type="text" name="new_password" placeholder="Enter New Password" required>

<button type="submit" name="reset_password">
Reset Password
</button>
</form>

</div>
</body>
</html>