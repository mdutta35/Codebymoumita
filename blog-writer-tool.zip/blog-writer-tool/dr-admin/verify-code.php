<?php
session_start();

$message = "";

if(!isset($_SESSION['reset_code']) || !isset($_SESSION['reset_email'])){
    header("Location: forgot-password.php");
    exit;
}

if(isset($_POST['verify_code'])){

    $enteredCode = trim($_POST['code']);

    if($enteredCode == $_SESSION['reset_code']){

        $_SESSION['code_verified'] = true;

        header("Location: reset-password.php");
        exit;

    }else{
        $message = "Invalid verification code";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Verify Code</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

body{
  font-family:'Poppins',sans-serif;
  min-height:100vh;
  display:flex;
  align-items:center;
  justify-content:center;
  background:linear-gradient(135deg,#c96b86,#df88a0);
}

.form-card{
  width:100%;
  max-width:400px;
  background:#fff;
  border-radius:24px;
  padding:30px;
}

input{
  width:100%;
  height:48px;
  border:1px solid #eee;
  border-radius:12px;
  padding:0 16px;
  margin-bottom:18px;
}

button{
  width:100%;
  height:48px;
  border:none;
  border-radius:12px;
  background:#cf6d86;
  color:#fff;
  cursor:pointer;
}

.error-msg{
  background:#ffe7e7;
  color:#c62828;
  padding:12px;
  border-radius:10px;
  margin-bottom:16px;
}

</style>

</head>

<body>

<div class="form-card">

<h2>Verify Code</h2>

<br>

<?php if($message != ""){ ?>

<div class="error-msg">

<?php echo $message; ?>

</div>

<?php } ?>

<form method="POST">

<input
type="text"
name="code"
placeholder="Enter Verification Code"
required
>

<button
type="submit"
name="verify_code"
>

Verify Code

</button>

</form>

</div>

</body>

</html>