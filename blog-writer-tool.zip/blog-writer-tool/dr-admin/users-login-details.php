<?php
session_start();

if(!isset($_SESSION['admin_id'])){
    header("Location: admin-login.php");
    exit;
}

include 'config.php';

$conn = new mysqli($host, $user, $pass, $db);

if($conn->connect_error){
    die("Database Connection Failed");
}



if(isset($_GET['delete'])){

    $deleteId = intval($_GET['delete']);

    mysqli_query(
        $conn,
        "DELETE FROM blog_writer_users WHERE id = '$deleteId'"
    );

    header("Location: users-login-details.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Users Login Details</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<style>
*{
  margin:0;
  padding:0;
  box-sizing:border-box;
}

body{
  font-family:'Poppins',sans-serif;
  background:#f5f6fa;
  overflow-x:hidden;
}

.admin-layout{
  display:flex;
  min-height:100vh;
}

.main-content{
  margin-left:280px;
  width:calc(100% - 280px);
  padding:30px;
}

.page-header{
  display:flex;
  align-items:center;
  justify-content:space-between;
  margin-bottom:30px;
}

.page-header h1{
  font-size:32px;
  color:#24324a;
}

.add-user-btn{
  display:flex;
  align-items:center;
  gap:10px;
  background:#cf6d86;
  color:#fff;
  text-decoration:none;
  padding:14px 22px;
  border-radius:14px;
  font-size:14px;
  font-weight:600;
  transition:0.3s;
}

.add-user-btn:hover{
  transform:translateY(-2px);
}

.table-card{
  background:#fff;
  border-radius:24px;
  padding:25px;
  box-shadow:0 10px 30px rgba(0,0,0,0.06);
}

.table-wrap{
  overflow-x:auto;
}

.table-wrap table{
  width:100%;
  border-collapse:collapse;
}

.table-wrap th,
.table-wrap td{
  padding:16px;
  border-bottom:1px solid #eee;
  text-align:left;
  font-size:14px;
}

.table-wrap th{
  color:#24324a;
  font-weight:600;
}

.table-wrap td{
  color:#666;
}

.delete-user-btn{
  display:inline-flex;
  align-items:center;
  justify-content:center;
  width:38px;
  height:38px;
  border-radius:10px;
  background:#d9534f;
  color:#fff;
  text-decoration:none;
  transition:0.3s;
}

.delete-user-btn:hover{
  transform:translateY(-2px);
}

@media(max-width:991px){
  .main-content{
    margin-left:0;
    width:100%;
    padding:20px;
  }
}

@media(max-width:768px){
  .page-header{
    flex-direction:column;
    align-items:flex-start;
    gap:15px;
  }

  .page-header h1{
    font-size:26px;
  }
}
</style>
</head>

<body>

<div class="admin-layout">

  <?php include 'sidebar.php'; ?>

  <main class="main-content">

    <div class="page-header">
      <div style="display:flex;align-items:center;gap:15px;">
        <button class="menu-btn" onclick="openSidebar()">
          <i class="bi bi-list"></i>
        </button>

        <h1>Users Login Details</h1>
        <a href="add-user.php" class="add-user-btn">

  <i class="bi bi-plus-circle"></i>

  Add User

</a>
      </div>
    </div>

    <div class="table-card">
      <div class="table-wrap">

        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Password</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody>
          <?php
          $query = mysqli_query($conn, "SELECT * FROM blog_writer_users ORDER BY id DESC");

          while($row = mysqli_fetch_assoc($query)){
          ?>
            <tr>
              <td><?php echo htmlspecialchars($row['id']); ?></td>
              <td><?php echo htmlspecialchars($row['name']); ?></td>
              <td><?php echo htmlspecialchars($row['email']); ?></td>
              <td><?php echo htmlspecialchars($row['password']); ?></td>
              <td>
                <a
                  href="?delete=<?php echo $row['id']; ?>"
                  class="delete-user-btn"
                  onclick="return confirm('Are you sure you want to delete this user?')"
                >
                  <i class="bi bi-trash"></i>
                </a>
              </td>
            </tr>
          <?php } ?>
          </tbody>
        </table>

      </div>
    </div>

  </main>

</div>

</body>
</html>