<?php
session_start();

if(!isset($_SESSION['admin_id'])){
    header("Location: admin-login.php");
    exit;
}

include 'config.php';

/* =========================
   DELETE SINGLE
========================= */

if(isset($_GET['delete'])){

    $deleteId = intval($_GET['delete']);

    mysqli_query(
        $conn,
        "DELETE FROM blog_requests WHERE id = '$deleteId'"
    );

    header("Location: university-search-history.php");
    exit;
}

/* =========================
   DELETE MULTIPLE
========================= */

if(isset($_POST['delete_selected'])){

    if(!empty($_POST['selected_rows'])){

        foreach($_POST['selected_rows'] as $id){

            $id = intval($id);

            mysqli_query(
                $conn,
                "DELETE FROM blog_requests WHERE id = '$id'"
            );
        }
    }

    header("Location: university-search-history.php");
    exit;
}

/* =========================
   SEARCH
========================= */

$search = $_GET['search'] ?? '';
$userFilter = $_GET['user_name'] ?? '';

/* =========================
   PAGINATION
========================= */

$limit = 10;

$page = isset($_GET['page'])
    ? (int)$_GET['page']
    : 1;

$offset = ($page - 1) * $limit;

/* =========================
   SEARCH QUERY
========================= */

$whereConditions = [];

if($search != ''){

    $searchSafe = mysqli_real_escape_string($conn, $search);

    $whereConditions[] = "
        (
            university_name LIKE '%$searchSafe%'
            OR topic LIKE '%$searchSafe%'
            OR keyword1 LIKE '%$searchSafe%'
        )
    ";
}

if($userFilter != ''){

    $userFilterSafe = mysqli_real_escape_string($conn, $userFilter);

    $whereConditions[] = "user_name = '$userFilterSafe'";
}

$where = "";

if(count($whereConditions) > 0){
    $where = "WHERE " . implode(" AND ", $whereConditions);
}

/* =========================
   TOTAL ROWS
========================= */

$totalQuery = mysqli_query(
    $conn,
    "SELECT COUNT(*) as total
     FROM blog_requests
     $where"
);

$totalData = mysqli_fetch_assoc($totalQuery);

$totalRows = $totalData['total'];

$totalPages = ceil($totalRows / $limit);

/* =========================
   MAIN QUERY
========================= */

$query = mysqli_query(
    $conn,
    "SELECT *
     FROM blog_requests
     $where
     ORDER BY id DESC
     LIMIT $offset,$limit"
);

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Search History</title>

<link rel="preconnect" href="https://fonts.googleapis.com">

<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<style>

*{
  margin:0;
  padding:0;
  box-sizing:border-box;
}

body{
  font-family:'Poppins',sans-serif;
  background:#f5f6fa;
  overflow-x:hidden;
}


.admin-layout{
  display:flex;
}

.main-content{
  margin-left:280px;
  width:calc(100% - 280px);
  padding:30px;
}

.page-header{
  display:flex;
  align-items:center;
  justify-content:space-between;
  margin-bottom:25px;
}

.page-header h1{
  font-size:32px;
  color:#24324a;
}

.header-left{
  display:flex;
  align-items:center;
  gap:16px;
}

.back-btn{
  display:flex;
  align-items:center;
  gap:8px;
  padding:12px 18px;
  border-radius:30px;
  background:#fff;
  text-decoration:none;
  color:#24324a;
  font-size:14px;
  font-weight:600;
  box-shadow:0 8px 20px rgba(0,0,0,0.06);
  transition:0.3s;
}

.back-btn i{
  font-size:18px;
}

.back-btn:hover{
  background:#cf6d86;
  color:#fff;
  transform:translateY(-2px);
}

.top-bar{
  display:flex;
  gap:15px;
  margin-bottom:25px;
  flex-wrap:wrap;
}

.search-box{
  flex:1;
}

.search-box input{
  width:100%;
  height:52px;
  border:none;
  border-radius:14px;
  padding:0 18px;
  font-size:14px;
  background:#fff;
  outline:none;
}

.filter-box select{
  width:240px;
  height:52px;
  border:none;
  border-radius:14px;
  padding:0 18px;
  font-size:14px;
  background:#fff;
  outline:none;
  font-family:'Poppins',sans-serif;
}

.search-btn,
.delete-btn{
  height:52px;
  padding:0 22px;
  border:none;
  border-radius:14px;
  color:#fff;
  cursor:pointer;
  font-weight:600;
  font-family:'Poppins',sans-serif;
}

.search-btn{
  background:#cf6d86;
}

.delete-btn{
  background:#d9534f;
}

.table-card{
  background:#fff;
  border-radius:24px;
  padding:25px;
  box-shadow:0 10px 30px rgba(0,0,0,0.06);
}

.table-wrap{
  overflow-x:auto;
}

table{
  width:100%;
  border-collapse:collapse;
  min-width:3200px;
}

th,
td{
  padding:14px;
  border-bottom:1px solid #eee;
  text-align:left;
  font-size:13px;
}

th{
  background:#fafafa;
  color:#24324a;
  font-weight:600;
}

td{
  color:#666;
}

.action-btn{
  display:flex;
  align-items:center;
  justify-content:center;
  width:38px;
  height:38px;
  border-radius:10px;
  text-decoration:none;
  color:#fff;
  flex-shrink:0;
}

.actions-box{
  display:flex;
  align-items:center;
  gap:8px;
}

.pdf-btn{
  background:#cf6d86;
}

.delete-single{
  background:#d9534f;
}

.pagination{
  display:flex;
  gap:10px;
  margin-top:25px;
  flex-wrap:wrap;
}

.pagination a{
  width:42px;
  height:42px;
  border-radius:12px;
  background:#fff;
  display:flex;
  align-items:center;
  justify-content:center;
  text-decoration:none;
  color:#24324a;
  font-weight:600;
}

.pagination a.active{
  background:#cf6d86;
  color:#fff;
}

.checkbox-input{
  width:18px;
  height:18px;
  cursor:pointer;
}

@media(max-width:991px){

  .main-content{
    margin-left:0;
    width:100%;
    padding:20px;
  }
}

</style>

</head>

<body>

<div class="admin-layout">

<?php include 'sidebar.php'; ?>

<div class="main-content">

<div class="page-header">

<div class="header-left">

<a href="search-history.php" class="back-btn">
<i class="bi bi-arrow-return-left"></i>
Return
</a>

<h1>AI-Powered Blog Writing Tool History</h1>

</div>

</div>

<!-- SEARCH -->

<form method="GET">

<div class="top-bar">

<div class="search-box">

<input
type="text"
name="search"
placeholder="Search university, topic or keyword..."
value="<?php echo htmlspecialchars($search); ?>"
>

</div>

<div class="filter-box">

<select name="user_name">

<option value="">All Users</option>

<?php

$userDropdownQuery = mysqli_query(
    $conn,
    "SELECT DISTINCT user_name 
     FROM blog_requests 
     WHERE user_name IS NOT NULL 
     AND user_name != ''
     ORDER BY user_name ASC"
);

while($userRow = mysqli_fetch_assoc($userDropdownQuery)){

    $selected = "";

    if($userFilter == $userRow['user_name']){
        $selected = "selected";
    }

?>

<option
value="<?php echo htmlspecialchars($userRow['user_name']); ?>"
<?php echo $selected; ?>
>
<?php echo htmlspecialchars($userRow['user_name']); ?>
</option>

<?php } ?>

</select>

</div>

<button type="submit" class="search-btn">

<i class="bi bi-search"></i>
Search

</button>

</div>

</form>

<!-- TABLE -->

<form method="POST">

<div class="table-card">

<div class="table-wrap">

<table>

<thead>
<tr>
  <th>
    <input type="checkbox" id="selectAll" class="checkbox-input">
  </th>

  <th>ID</th>
  <th>Entered By</th>
  <th>University Name</th>
  <th>University City</th>
  <th>NAAC</th>
  <th>Affiliation</th>
  <th>Topic</th>
  <th>Intent</th>
  <th>Audience</th>
  <th>Keyword 1</th>
  <th>Keyword 2</th>
  <th>Meta Title</th>
  <th>Meta Description</th>
  <th>Word Count</th>
  <th>Tone</th>
  <th>GEO Targets</th>
  <th>Schema Types</th>
  <th>USPs</th>
  <th>Programs</th>
  <th>Differentiators</th>
  <th>PAA</th>
  <th>Internal Links</th>
  <th>Special Instructions</th>
  <th>AI Response</th>
  <th>Created At</th>
  <th>Actions</th>
</tr>
</thead>

<tbody>

<?php while($row = mysqli_fetch_assoc($query)){ ?>

<tr>
  <td>
    <input
      type="checkbox"
      name="selected_rows[]"
      value="<?php echo $row['id']; ?>"
      class="checkbox-input rowCheckbox"
    >
  </td>

  <td><?php echo htmlspecialchars($row['id'] ?? ''); ?></td>
  <td><?php echo htmlspecialchars($row['user_name'] ?? ''); ?></td>
  <td><?php echo htmlspecialchars($row['university_name'] ?? ''); ?></td>
  <td><?php echo htmlspecialchars($row['university_city'] ?? ''); ?></td>
  <td><?php echo htmlspecialchars($row['naac'] ?? ''); ?></td>
  <td><?php echo htmlspecialchars($row['affiliation'] ?? ''); ?></td>
  <td><?php echo htmlspecialchars($row['topic'] ?? ''); ?></td>
  <td><?php echo htmlspecialchars($row['intent'] ?? ''); ?></td>
  <td><?php echo htmlspecialchars($row['audience'] ?? ''); ?></td>
  <td><?php echo htmlspecialchars($row['keyword1'] ?? ''); ?></td>
  <td><?php echo htmlspecialchars($row['keyword2'] ?? ''); ?></td>
  <td><?php echo htmlspecialchars($row['meta_title'] ?? ''); ?></td>
  <td><?php echo htmlspecialchars($row['meta_description'] ?? ''); ?></td>
  <td><?php echo htmlspecialchars($row['word_count'] ?? ''); ?></td>
  <td><?php echo htmlspecialchars($row['tone'] ?? ''); ?></td>
  <td><?php echo htmlspecialchars($row['geo_targets'] ?? ''); ?></td>
  <td><?php echo htmlspecialchars($row['schema_types'] ?? ''); ?></td>
  <td><?php echo htmlspecialchars($row['usps'] ?? ''); ?></td>
  <td><?php echo htmlspecialchars($row['programs'] ?? ''); ?></td>
  <td><?php echo htmlspecialchars($row['differentiators'] ?? ''); ?></td>
  <td><?php echo htmlspecialchars($row['paa'] ?? ''); ?></td>
  <td><?php echo htmlspecialchars($row['internal_links'] ?? ''); ?></td>
  <td><?php echo htmlspecialchars($row['special_instructions'] ?? ''); ?></td>
  <td><?php echo htmlspecialchars($row['ai_response'] ?? ''); ?></td>
  <td><?php echo htmlspecialchars($row['created_at'] ?? ''); ?></td>

  <td class="actions-box">
    <?php if(!empty($row['pdf_file'])){ ?>

<a
href="../generated-pdfs/<?php echo basename($row['pdf_file']); ?>"
class="action-btn pdf-btn"
target="_blank"
title="Open Saved PDF"
>
<i class="bi bi-file-earmark-pdf"></i>
</a>

<?php }else{ ?>

<a
href="generate-pdf.php?id=<?php echo $row['id']; ?>"
class="action-btn pdf-btn"
target="_blank"
title="Generate PDF"
>
<i class="bi bi-file-earmark-pdf"></i>
</a>

<?php } ?>

    <a
      href="?delete=<?php echo $row['id']; ?>"
      class="action-btn delete-single"
      onclick="return confirm('Delete this row?')"
    >
      <i class="bi bi-trash"></i>
    </a>
  </td>
</tr>

<?php } ?>

</tbody>

</table>

</div>

<br>

<button
type="submit"
name="delete_selected"
class="delete-btn"
onclick="return confirm('Delete selected rows?')"
>

Delete Selected

</button>

</div>

</form>

<!-- PAGINATION -->

<div class="pagination">

<?php for($i=1; $i<=$totalPages; $i++){ ?>

<a
href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&user_name=<?php echo urlencode($userFilter); ?>"
class="<?php if($page == $i){ echo 'active'; } ?>"
>

<?php echo $i; ?>

</a>

<?php } ?>

</div>

</div>

</div>

<script>

/* =========================
   SELECT ALL
========================= */

const selectAll =
document.getElementById('selectAll');

const rowCheckboxes =
document.querySelectorAll('.rowCheckbox');

selectAll.addEventListener(
  'change',
  function(){

    rowCheckboxes.forEach(cb => {

      cb.checked = this.checked;

    });

  }
);

</script>

</body>

</html>