-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 18, 2026 at 02:56 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `university_blog_writer`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog_requests`
--

CREATE TABLE `blog_requests` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `university_name` varchar(255) DEFAULT NULL,
  `university_city` varchar(255) DEFAULT NULL,
  `naac` varchar(255) DEFAULT NULL,
  `affiliation` varchar(255) DEFAULT NULL,
  `topic` text DEFAULT NULL,
  `intent` varchar(255) DEFAULT NULL,
  `audience` varchar(255) DEFAULT NULL,
  `keyword1` varchar(255) DEFAULT NULL,
  `keyword2` varchar(255) DEFAULT NULL,
  `meta_title` text DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `word_count` varchar(50) DEFAULT NULL,
  `tone` varchar(100) DEFAULT NULL,
  `geo_targets` text DEFAULT NULL,
  `schema_types` text DEFAULT NULL,
  `usps` longtext DEFAULT NULL,
  `programs` longtext DEFAULT NULL,
  `differentiators` longtext DEFAULT NULL,
  `paa` longtext DEFAULT NULL,
  `internal_links` longtext DEFAULT NULL,
  `special_instructions` longtext DEFAULT NULL,
  `ai_response` longtext DEFAULT NULL,
  `pdf_file` longtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blog_requests`
--

INSERT INTO `blog_requests` (`id`, `user_name`, `university_name`, `university_city`, `naac`, `affiliation`, `topic`, `intent`, `audience`, `keyword1`, `keyword2`, `meta_title`, `meta_description`, `word_count`, `tone`, `geo_targets`, `schema_types`, `usps`, `programs`, `differentiators`, `paa`, `internal_links`, `special_instructions`, `ai_response`, `pdf_file`, `created_at`) VALUES
(144, 'user one', 'q', '', '', '', 'q', 'informational', '12th students', '', '', '', '', '1800', 'humanized, warm and conversational', '', 'Article', '', '', '', '', '', '', 'Claude API: Your credit balance is too low to access the Anthropic API. Please go to Plans & Billing to upgrade or purchase credits.', NULL, '2026-05-18 10:47:26'),
(145, 'user one', 'q', '', '', '', 'q', 'informational', '12th students', '', '', '', '', '1800', 'humanized, warm and conversational', '', 'Article', '', '', '', '', '', '', 'Claude API: Your credit balance is too low to access the Anthropic API. Please go to Plans & Billing to upgrade or purchase credits.', 'generated-pdfs/ai_blog_report_145_1779101757.pdf', '2026-05-18 10:55:54'),
(146, 'user one', 'q', '', '', '', 'q', 'informational', '12th students', '', '', '', '', '1800', 'humanized, warm and conversational', '', 'Article', '', '', '', '', '', '', 'Claude API: Your credit balance is too low to access the Anthropic API. Please go to Plans & Billing to upgrade or purchase credits.', 'generated-pdfs/ai_blog_report_146_1779102942.pdf', '2026-05-18 11:15:38');

-- --------------------------------------------------------

--
-- Table structure for table `blog_writer_admin_login`
--

CREATE TABLE `blog_writer_admin_login` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blog_writer_admin_login`
--

INSERT INTO `blog_writer_admin_login` (`id`, `name`, `email`, `password`, `created_at`) VALUES
(1, 'admin', 'counsellor3.digitalreach@gmail.com', 'admin', '2026-05-13 05:10:29');

-- --------------------------------------------------------

--
-- Table structure for table `blog_writer_sub_admin`
--

CREATE TABLE `blog_writer_sub_admin` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(150) NOT NULL,
  `permissions` text DEFAULT NULL,
  `status` enum('Active','Inactive') DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blog_writer_sub_admin`
--

INSERT INTO `blog_writer_sub_admin` (`id`, `name`, `email`, `password`, `permissions`, `status`, `created_at`) VALUES
(1, 'sub admin', 'subadmin@gmail.com', 'subadmin', NULL, 'Active', '2026-05-16 12:37:13');

-- --------------------------------------------------------

--
-- Table structure for table `blog_writer_users`
--

CREATE TABLE `blog_writer_users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blog_writer_users`
--

INSERT INTO `blog_writer_users` (`id`, `name`, `email`, `password`) VALUES
(1, 'user', 'user@gmail.com', 'user'),
(4, 'user one', 'userone@gmail.com', 'userone');

-- --------------------------------------------------------

--
-- Table structure for table `blog_writer_user_login_history`
--

CREATE TABLE `blog_writer_user_login_history` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(150) DEFAULT NULL,
  `user_email` varchar(150) DEFAULT NULL,
  `user_type` varchar(50) DEFAULT NULL,
  `prompt_name` varchar(255) DEFAULT NULL,
  `prompt_count` int(11) DEFAULT 0,
  `login_time` datetime NOT NULL,
  `logout_time` datetime DEFAULT NULL,
  `duration_seconds` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blog_writer_user_login_history`
--

INSERT INTO `blog_writer_user_login_history` (`id`, `user_id`, `user_name`, `user_email`, `user_type`, `prompt_name`, `prompt_count`, `login_time`, `logout_time`, `duration_seconds`, `created_at`) VALUES
(1, 4, 'user one', 'userone@gmail.com', NULL, NULL, 0, '2026-05-18 08:49:16', '2026-05-18 08:49:24', 8, '2026-05-18 06:49:16'),
(2, 4, 'user one', 'userone@gmail.com', NULL, NULL, 0, '2026-05-18 09:20:59', '2026-05-18 09:27:41', 402, '2026-05-18 07:20:59'),
(3, 4, 'user one', 'userone@gmail.com', NULL, NULL, 0, '2026-05-18 09:27:49', '2026-05-18 09:27:56', 7, '2026-05-18 07:27:49'),
(4, 4, 'user one', 'userone@gmail.com', NULL, NULL, 0, '2026-05-18 09:28:02', NULL, 0, '2026-05-18 07:28:02'),
(5, 4, 'user one', 'userone@gmail.com', NULL, NULL, 0, '2026-05-18 11:50:08', NULL, 0, '2026-05-18 09:50:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog_requests`
--
ALTER TABLE `blog_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_writer_admin_login`
--
ALTER TABLE `blog_writer_admin_login`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `blog_writer_sub_admin`
--
ALTER TABLE `blog_writer_sub_admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `blog_writer_users`
--
ALTER TABLE `blog_writer_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `blog_writer_user_login_history`
--
ALTER TABLE `blog_writer_user_login_history`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog_requests`
--
ALTER TABLE `blog_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=147;

--
-- AUTO_INCREMENT for table `blog_writer_admin_login`
--
ALTER TABLE `blog_writer_admin_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `blog_writer_sub_admin`
--
ALTER TABLE `blog_writer_sub_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `blog_writer_users`
--
ALTER TABLE `blog_writer_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `blog_writer_user_login_history`
--
ALTER TABLE `blog_writer_user_login_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
