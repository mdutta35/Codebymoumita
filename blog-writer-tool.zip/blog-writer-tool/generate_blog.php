<?php
// generate_blog.php
session_start();
header('Content-Type: application/json');

// Log all errors to a file (helps debugging — open generate_blog_errors.log to see issues)
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/generate_blog_errors.log');

// ============================================================
// 1. YOUR ANTHROPIC API KEY  ← REPLACE THIS WITH THE REAL KEY
//    Get it from: https://console.anthropic.com/settings/keys
// ============================================================
$ANTHROPIC_API_KEY = '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';

// ============================================================
// 2. MODEL — pick one. Sonnet 4.6 is recommended for blogs
//    (Opus quality at lower cost). Use Opus 4.7 for highest quality.
// ============================================================
$MODEL = 'claude-3-5-sonnet-20241022';   // recommended for blog writing
// $MODEL = 'claude-opus-4-7';  // use this for premium quality

// ----- Basic guards -----
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
    exit;
}

if (strpos($ANTHROPIC_API_KEY, 'PASTE') !== false || strlen($ANTHROPIC_API_KEY) < 20) {
    echo json_encode([
        'status'  => 'error',
        'message' => 'API key is not set. Open generate_blog.php and paste your real Anthropic key.'
    ]);
    exit;
}

// ----- Collect all form fields -----
$f = [
    'user_name'            => trim($_POST['user_name']            ?? ''),
    'university_name'      => trim($_POST['university_name']      ?? ''),
    'university_city'      => trim($_POST['university_city']      ?? ''),
    'naac'                 => trim($_POST['naac']                 ?? ''),
    'affiliation'          => trim($_POST['affiliation']          ?? ''),
    'topic'                => trim($_POST['topic']                ?? ''),
    'intent'               => trim($_POST['intent']               ?? ''),
    'audience'             => trim($_POST['audience']             ?? ''),
    'keyword1'             => trim($_POST['keyword1']             ?? ''),
    'keyword2'             => trim($_POST['keyword2']             ?? ''),
    'meta_title'           => trim($_POST['meta_title']           ?? ''),
    'meta_description'     => trim($_POST['meta_description']     ?? ''),
    'word_count'           => trim($_POST['word_count']           ?? '1800'),
    'tone'                 => trim($_POST['tone']                 ?? ''),
    'geo_targets'          => trim($_POST['geo_targets']          ?? ''),
    'schema_types'         => trim($_POST['schema_types']         ?? 'Article'),
    'usps'                 => trim($_POST['usps']                 ?? ''),
    'programs'             => trim($_POST['programs']             ?? ''),
    'differentiators'      => trim($_POST['differentiators']      ?? ''),
    'paa'                  => trim($_POST['paa']                  ?? ''),
    'internal_links'       => trim($_POST['internal_links']       ?? ''),
    'special_instructions' => trim($_POST['special_instructions'] ?? '')
];

if ($f['topic'] === '' || $f['university_name'] === '') {
    echo json_encode(['status' => 'error', 'message' => 'University name and topic are required']);
    exit;
}

// ----- Build the prompt -----
$prompt = <<<PROMPT
You are an expert SEO + GEO + LLM-optimization content writer specializing in
Indian private universities. Write a complete, publish-ready blog post in clean
HTML (use <h1>, <h2>, <h3>, <p>, <ul>, <li>, <strong>) — do NOT wrap the output
in <html> or <body> tags, and do not use markdown.

=================== UNIVERSITY PROFILE ===================
University Name : {$f['university_name']}
Location        : {$f['university_city']}
NAAC / Ranking  : {$f['naac']}
Affiliation     : {$f['affiliation']}

=================== BLOG TOPIC & INTENT ===================
Blog Topic        : {$f['topic']}
Search Intent     : {$f['intent']}
Target Audience   : {$f['audience']}
Primary Keyword   : {$f['keyword1']}
Secondary / LSI   : {$f['keyword2']}

=================== SEO / GEO SETTINGS ===================
Meta Title       : {$f['meta_title']}
Meta Description : {$f['meta_description']}
Target Word Count: {$f['word_count']} words
Tone of Voice    : {$f['tone']}
GEO Locations    : {$f['geo_targets']}
Schema Type      : {$f['schema_types']}

=================== LLM / AI-SEO INPUTS ===================
USPs                  : {$f['usps']}
Programs to Highlight : {$f['programs']}
Differentiators       : {$f['differentiators']}
People Also Ask       : {$f['paa']}
Internal Links        : {$f['internal_links']}
Special Instructions  : {$f['special_instructions']}

=================== OUTPUT REQUIREMENTS ===================
1. Start with:
   <p><strong>Meta Title:</strong> ...</p>
   <p><strong>Meta Description:</strong> ...</p>
   (Auto-generate if blank.)
2. Then the blog:
   - <h1> Catchy SEO title with the primary keyword
   - Short hook intro (2–3 sentences)
   - <h2> sections with <h3> sub-sections
   - Bullet lists where useful
   - <h2>FAQs</h2> section answering the People Also Ask topics
   - Final CTA paragraph
3. Humanized, natural, varied sentence length, no AI fluff.
4. Naturally include the primary keyword in H1, first 100 words, one H2, conclusion.
   Sprinkle LSI keywords. Never stuff.
5. Bake in GEO locations naturally.
6. End with a JSON-LD <script type="application/ld+json"> block for: {$f['schema_types']}.
7. Target roughly {$f['word_count']} words. Do not pad.
8. Follow the Special Instructions strictly.

Now produce the full blog.
PROMPT;

// ----- Call Anthropic API -----
$payload = json_encode([
    'model'      => $MODEL,
    'max_tokens' => 8000,
    'messages' => [
    [
        'role' => 'user',
        'content' => [
            [
                'type' => 'text',
                'text' => $prompt
            ]
        ]
    ]
]
]);

$ch = curl_init('https://api.anthropic.com/v1/messages');
curl_setopt_array($ch, [
    CURLOPT_POST           => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POSTFIELDS     => $payload,
    CURLOPT_TIMEOUT        => 180,
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'x-api-key: ' . $ANTHROPIC_API_KEY,
        'anthropic-version: 2023-06-01'
    ]
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr  = curl_error($ch);
curl_close($ch);

// ----- Handle errors -----
if ($curlErr) {
    error_log("cURL error: $curlErr");
    echo json_encode(['status' => 'error', 'message' => 'Connection error: ' . $curlErr]);
    exit;
}

$data = json_decode($response, true);

if ($httpCode !== 200) {
    $msg = $data['error']['message'] ?? ('HTTP ' . $httpCode);
    error_log("Claude API error (HTTP $httpCode): $response");
    echo json_encode(['status' => 'error', 'message' => 'Claude API: ' . $msg]);
    exit;
}

$blogHtml = $data['content'][0]['text'] ?? '';

if ($blogHtml === '') {
    error_log("Empty content from API. Raw response: $response");
    echo json_encode(['status' => 'error', 'message' => 'API returned empty content']);
    exit;
}

// ----- (Optional) Save generated blog to DB -----
// Uncomment this block if you want to also save the AI output to MySQL.
// First add the column: ALTER TABLE blog_requests ADD COLUMN generated_blog LONGTEXT;
/*
try {
    $mysqli = new mysqli('localhost', 'root', '', 'university_blog_writer');
    if (!$mysqli->connect_error) {
        $stmt = $mysqli->prepare(
            "INSERT INTO blog_requests
             (user_name, university_name, university_city, naac, affiliation, topic, intent,
              audience, keyword1, keyword2, meta_title, meta_description, word_count, tone,
              geo_targets, schema_types, usps, programs, differentiators, paa, internal_links,
              special_instructions, generated_blog)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
        );
        $stmt->bind_param(
            "sssssssssssssssssssssss",
            $f['user_name'], $f['university_name'], $f['university_city'], $f['naac'],
            $f['affiliation'], $f['topic'], $f['intent'], $f['audience'],
            $f['keyword1'], $f['keyword2'], $f['meta_title'], $f['meta_description'],
            $f['word_count'], $f['tone'], $f['geo_targets'], $f['schema_types'],
            $f['usps'], $f['programs'], $f['differentiators'], $f['paa'],
            $f['internal_links'], $f['special_instructions'], $blogHtml
        );
        $stmt->execute();
        $stmt->close();
        $mysqli->close();
    }
} catch (Exception $e) {
    error_log("DB save failed: " . $e->getMessage());
    // Don't fail the request — blog still returns
}
*/

// ----- Return result -----
echo json_encode([
    'status' => 'success',
    'blog'   => $blogHtml,
    'model'  => $MODEL
]);