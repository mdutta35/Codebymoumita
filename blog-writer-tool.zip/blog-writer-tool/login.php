<?php
session_start();

/* =========================
   DATABASE CONNECTION
========================= */

include 'dr-admin/config.php';



$requestMsg = "";

if(isset($_POST['password_request_submit'])){

    $requestName = trim($_POST['request_name']);
    $requestEmail = trim($_POST['request_email']);

    if($requestName == "" || $requestEmail == ""){
        $requestMsg = "Please fill all request fields.";
    } else {

        $to = "counsellor3.digitalreach@gmail.com";
        $subject = "New ID Password Request - Blog Writer Tool";

        $message = "
        Name: $requestName
        Email: $requestEmail

        This user has requested login ID/password access for the University Blog Writer Tool.
        ";

        $headers = "From: noreply@digitalreach.digital\r\n";
        $headers .= "Reply-To: $requestEmail\r\n";

        if(mail($to, $subject, $message, $headers)){
            $requestMsg = "Password request sent successfully.";
        } else {
            $requestMsg = "Mail could not be sent. Please check server mail settings.";
        }
    }
}


/* =========================
   LOGIN LOGIC
========================= */

$error = "";

if (
    $_SERVER["REQUEST_METHOD"] == "POST"
    && !isset($_POST['password_request_submit'])
) {

    $email = trim($_POST['email'] ?? '');
    $pass  = trim($_POST['password'] ?? '');

    if (empty($email) || empty($pass)) {

        $error = "Please fill all fields.";

    } else {

        $stmt = $conn->prepare("SELECT * FROM blog_writer_users WHERE email = ? LIMIT 1");

        $stmt->bind_param("s", $email);

        $stmt->execute();

        $result = $stmt->get_result();

        if ($result->num_rows > 0) {

            $user = $result->fetch_assoc();

            /* =========================
               PASSWORD VERIFY
            ========================= */

            if ($pass == $user['password']) {

                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_email'] = $user['email'];

                $_SESSION['login_time'] = date("Y-m-d H:i:s");

mysqli_query(
    $conn,
    "INSERT INTO blog_writer_user_login_history
    (user_id, user_name, user_email, login_time)
    VALUES
    ('".$_SESSION['user_id']."',
     '".$_SESSION['user_name']."',
     '".$_SESSION['user_email']."',
     '".$_SESSION['login_time']."')"
);

$_SESSION['login_history_id'] = mysqli_insert_id($conn);

                header("Location: dashboard.php");
                exit;

            } else {

                $error = "Invalid password.";
            }

        } else {

            $error = "Email not found.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="UTF-8">

  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>Login</title>

  <!-- Poppins Font -->

  <link rel="preconnect" href="https://fonts.googleapis.com">

  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

  <link
    href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap"
    rel="stylesheet"
  >

  <style>

    *{
      margin:0;
      padding:0;
      box-sizing:border-box;
    }

    body{
      font-family:'Poppins',sans-serif;
      background:linear-gradient(135deg,#c96b86,#df88a0);
      min-height:100vh;
      display:flex;
      align-items:center;
      justify-content:center;
      overflow:hidden;
      position:relative;
      padding:20px;
    }


    .popup-overlay{
  position:fixed;
  inset:0;
  background:rgba(0,0,0,0.45);
  display:none;
  align-items:center;
  justify-content:center;
  z-index:9999;
  padding:20px;
}

.popup-overlay.show{
  display:flex;
}

.popup-box{
  width:100%;
  max-width:420px;
  background:#fff;
  border-radius:24px;
  padding:32px;
  position:relative;
  box-shadow:0 20px 60px rgba(0,0,0,0.18);
  text-align:left;
}

.popup-box h2{
  font-size:26px;
  color:#24324a;
  margin-bottom:8px;
}

.popup-box p{
  font-size:14px;
  color:#666;
  line-height:1.6;
  margin-bottom:22px;
}

.popup-close{
  position:absolute;
  top:16px;
  right:18px;
  border:none;
  background:none;
  font-size:28px;
  cursor:pointer;
  color:#cf6d86;
}



    /* BACKGROUND */

    body::before{
      content:"";
      position:absolute;
      width:700px;
      height:700px;
      background:rgba(255,255,255,0.08);
      border-radius:50%;
      top:-250px;
      left:-200px;
    }

    body::after{
      content:"";
      position:absolute;
      width:800px;
      height:800px;
      background:rgba(255,255,255,0.05);
      border-radius:50%;
      bottom:-350px;
      right:-250px;
    }

    /* LOGIN CARD */

    .login-card{
  width:100%;
  max-width:420px;
  background:rgba(255,255,255,0.96);
  border-radius:28px;
  padding:35px 32px;
  box-shadow:0 20px 60px rgba(0,0,0,0.12);
  position:relative;
  z-index:2;
  text-align:center;
}

/* REQUEST PASSWORD */

.request-password{
  margin-top:18px;
  text-align:center;
}

.request-password a{
  font-size:14px;
  font-weight:500;
  color:#cf6d86;
  text-decoration:none;
  transition:0.3s;
}

.request-password a:hover{
  opacity:0.8;
  text-decoration:underline;
}

    /* LOGO */

    .logo-box{
  width:90px;
  height:90px;
  background:#fff;
  border-radius:50%;
  display:flex;
  align-items:center;
  justify-content:center;
  margin:0 auto 18px;
  box-shadow:0 10px 30px rgba(0,0,0,0.1);
}

    .logo-box img{
      width:75px;
      object-fit:contain;
    }

    /* TEXT */

    h1{
  font-size:32px;
  font-weight:700;
  color:#24324a;
  margin-bottom:8px;
}

    .login-text{
  font-size:14px;
  color:#666;
  line-height:1.6;
  margin-bottom:24px;
}

    /* ERROR */

    .error-msg{
      background:#ffe7e7;
      color:#c62828;
      padding:12px;
      border-radius:10px;
      margin-bottom:20px;
      font-size:14px;
      text-align:left;
    }

    /* FORM */

    .input-group{
      text-align:left;
      margin-bottom:22px;
    }

    .input-group label{
      display:block;
      font-size:14px;
      font-weight:500;
      color:#24324a;
      margin-bottom:10px;
    }

    .input-group input{
      width:100%;
      height:58px;
      border-radius:14px;
      border:1px solid #e5e5e5;
      padding:0 18px;
      font-size:15px;
      font-family:'Poppins',sans-serif;
      outline:none;
      transition:0.3s;
    }

    .input-group input:focus{
      border-color:#cf6d86;
    }

    /* BUTTON */

    .login-btn{
      width:100%;
      height:60px;
      border:none;
      border-radius:14px;
      background:linear-gradient(to right,#cf6d86,#df88a0);
      color:#fff;
      font-size:17px;
      font-weight:600;
      font-family:'Poppins',sans-serif;
      cursor:pointer;
      transition:0.3s;
      margin-top:10px;
    }

    .login-btn:hover{
      transform:translateY(-2px);
      opacity:0.95;
    }

    /* RESPONSIVE */

    @media(max-width:576px){

      .login-card{
        padding:25px 14px;
        border-radius:25px;
      }

      .logo-box{
        width:90px;
        height:90px;
      }

      .logo-box img{
        width:60px;
      }

      h1{
        font-size:30px;
      }

      .login-text{
        font-size:14px;
      }

      .input-group input{
        height:54px;
      }

      .login-btn{
        height:56px;
        font-size:16px;
      }
    }


    /* =========================
   RESPONSIVE
========================= */

@media(max-width:768px){

  body{
    padding:16px;
    overflow:auto;
  }

  .login-card{
    max-width:100%;
    padding:28px 22px;
    border-radius:24px;
  }

  /* LOGO */

  .logo-box{
    width:80px;
    height:80px;
    margin-bottom:16px;
  }

  .logo-box img{
    width:52px;
  }

  /* TITLE */

  h1{
    font-size:28px;
    line-height:1.2;
    margin-bottom:6px;
  }

  .login-text{
    font-size:13px;
    line-height:1.6;
    margin-bottom:22px;
  }

  /* FORM */

  .input-group{
    margin-bottom:18px;
  }

  .input-group label{
    font-size:13px;
    margin-bottom:8px;
  }

  .input-group input{
    height:50px;
    border-radius:12px;
    padding:0 14px;
    font-size:14px;
  }

  /* BUTTON */

  .login-btn{
    height:52px;
    border-radius:12px;
    font-size:15px;
    margin-top:4px;
  }

  /* ERROR */

  .error-msg{
    font-size:13px;
    padding:10px;
    margin-bottom:16px;
  }

}

/* EXTRA SMALL MOBILE */

@media(max-width:480px){

  body{
    padding:14px;
  }

  .login-card{
    padding:24px 18px;
    border-radius:20px;
  }

  .logo-box{
    width:72px;
    height:72px;
  }

  .logo-box img{
    width:46px;
  }

  h1{
    font-size:24px;
  }

  .login-text{
    font-size:12px;
  }

  .input-group input{
    height:48px;
    font-size:13px;
  }

  .login-btn{
    height:50px;
    font-size:14px;
  }

}

  </style>

</head>

<body>

  <div class="login-card">

    <!-- LOGO -->

    <div class="logo-box">

      <img 
        src="images/DR logo-Transparent.png" 
        alt="Logo"
      >

    </div>

    <!-- TITLE -->

    <h1>Welcome</h1>

    <p class="login-text">
      Login to access the University Blog Writer dashboard
    </p>

    <!-- ERROR -->

    <?php if($error != ""): ?>

      <div class="error-msg">

        <?php echo $error; ?>

      </div>

    <?php endif; ?>

    <?php if($requestMsg != ""): ?>

  <div class="error-msg">

    <?php echo $requestMsg; ?>

  </div>

<?php endif; ?>

    <!-- FORM -->

    <form method="POST">

      <!-- EMAIL -->

      <div class="input-group">

        <label>Email Address</label>

        <input 
          type="email"
          name="email"
          placeholder="Enter your email"
          required
        >

      </div>

      <!-- PASSWORD -->

      <div class="input-group">

        <label>Password</label>

        <input 
          type="password"
          name="password"
          placeholder="Enter your password"
          required
        >

      </div>

      <!-- BUTTON -->

      <button type="submit" class="login-btn">

        Login

      </button>

      <div class="request-password">

    <a href="javascript:void(0)" onclick="openPasswordPopup()">
    Request for Password
</a>

    </div>

    </form>

  </div>


  <div class="popup-overlay" id="passwordPopup">

  <div class="popup-box">

    <button class="popup-close" onclick="closePasswordPopup()">×</button>

    <h2>Request for Password</h2>

    <p>Enter your details. Our team will contact you with login access.</p>

    <form method="POST">

      <div class="input-group">
        <label>Name</label>
        <input type="text" name="request_name" placeholder="Enter your name" required>
      </div>

      <div class="input-group">
        <label>Email Address</label>
        <input type="email" name="request_email" placeholder="Enter your email" required>
      </div>

      <button type="submit" name="password_request_submit" class="login-btn">
        Submit Request
      </button>

    </form>

  </div>

</div>

<script>
function openPasswordPopup(){
  document.getElementById('passwordPopup').classList.add('show');
}

function closePasswordPopup(){
  document.getElementById('passwordPopup').classList.remove('show');
}
</script>

</body>

</html>