<?php
include 'dr-admin/config.php';

header('Content-Type: application/json');

if(!isset($_GET['id'])){
    echo json_encode([
        "status" => "error",
        "message" => "Missing ID"
    ]);
    exit;
}

$id = intval($_GET['id']);

$query = mysqli_query(
    $conn,
    "SELECT * FROM blog_requests WHERE id='$id' LIMIT 1"
);

if(mysqli_num_rows($query) > 0){

    $data = mysqli_fetch_assoc($query);

    echo json_encode([
        "status" => "success",
        "data" => $data
    ]);

}else{

    echo json_encode([
        "status" => "error",
        "message" => "No data found"
    ]);
}
?>