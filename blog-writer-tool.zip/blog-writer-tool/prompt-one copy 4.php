<?php
session_start();

if (!isset($_SESSION['user_name'])) {
    header("Location: login.php");
    exit();
}

$userName = $_SESSION['user_name'];
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>University Blog Writer</title>

    <!-- Bootstrap 5 -->

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Poppins Font -->

    <link rel="preconnect" href="https://fonts.googleapis.com">

    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet">

    
<!-- Custom CSS -->
  <!-- <link rel="stylesheet" href="style.css"> -->

  <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap');

*{
  margin:0;
  padding:0;
  box-sizing:border-box;
}



body{
  font-family:'Poppins',sans-serif;
  background:linear-gradient(135deg,#c96b86,#df88a0);
  min-height:100vh;
  overflow-x:hidden;
  /* position:relative; */
  padding:60px 0;
}

.saved-data-box{
  margin-top:30px;
  background:#fff;
  border-radius:24px;
  padding:30px;
  box-shadow:0 15px 45px rgba(0,0,0,0.10);
  color:#24324a;
  line-height:1.8;
  display:none;
}

.saved-data-box h2{
  font-size:24px;
  font-weight:700;
  color:#24324a;
  margin-bottom:18px;
}

.saved-data-box p{
  font-size:15px;
  color:#555;
  margin-bottom:12px;
}

.saved-data-box strong{
  color:#cf6d86;
}

/* BACKGROUND SHAPES */

body::before{
  content:"";
  position:absolute;
  width:700px;
  height:700px;
  background:rgba(255,255,255,0.08);
  border-radius:50%;
  top:-250px;
  left:-200px;
}

body::after{
  content:"";
  position:absolute;
  width:800px;
  height:800px;
  background:rgba(255,255,255,0.05);
  border-radius:50%;
  bottom:-350px;
  right:-250px;
}

/* MAIN WRAPPER */

.wrap{
  position:relative;
  z-index:2;
  max-width:1100px;
  margin:auto;
  padding:0 15px;
}

/* =========================
   TOPBAR
========================= */

.topbar{
  display:flex;
  justify-content:flex-end;
  margin-bottom:25px;
}

/* PROFILE */

.profile-dropdown{
  position:relative;
}

.profile-btn{
  width:52px;
  height:52px;
  border:none;
  border-radius:50%;
  background:#fff;
  color:#cf6d86;
  font-size:18px;
  font-weight:700;
  cursor:pointer;
  box-shadow:0 10px 30px rgba(0,0,0,0.12);
  transition:0.3s;
}

.profile-btn:hover{
  transform:translateY(-2px);
}

/* MENU */

.profile-menu{
  position:absolute;
  top:65px;
  right:0;
  width:180px;
  background:#fff;
  border-radius:16px;
  padding:10px;
  box-shadow:0 20px 50px rgba(0,0,0,0.12);
  display:none;
  z-index:1000;
}

.profile-menu.show{
  display:block;
}

.profile-menu a{
  display:block;
  padding:12px 14px;
  border-radius:10px;
  text-decoration:none;
  color:#24324a;
  font-size:14px;
  font-weight:500;
  transition:0.3s;
}

.profile-menu a:hover{
  background:#f7f7f7;
  color:#cf6d86;
}

/* HERO SECTION */

.hero-box{
  text-align:center;
  color:#fff;
  margin-bottom:50px;
}

.logo-box{
  width:120px;
  height:120px;
  background:#fff;
  border-radius:50%;
  display:flex;
  align-items:center;
  justify-content:center;
  margin:auto auto 25px;
  box-shadow:0 10px 30px rgba(0,0,0,0.12);
}

.logo-box img{
  width:90px;
  object-fit:contain;
}

.hero-title{
  font-size:64px;
  line-height:1.1;
  font-weight:800;
  margin-bottom:20px;
}

.hero-text{
  font-size:20px;
  line-height:1.8;
  color:rgba(255,255,255,0.92);
  max-width:850px;
  margin:auto auto 30px;
}

.badge-row{
  display:flex;
  justify-content:center;
  flex-wrap:wrap;
  gap:14px;
}

.badge,
.badge2,
.badge3{
  padding:12px 20px;
  border-radius:50px;
  font-size:14px;
  font-weight:500;
  border:1px solid rgba(255,255,255,0.18);
  background:rgba(255,255,255,0.12);
  color:#fff;
  backdrop-filter:blur(8px);
}

/* FORM CARD */

.form-card{
  background:rgba(255,255,255,0.96);
  border-radius:35px;
  padding:50px;
  box-shadow:0 20px 60px rgba(0,0,0,0.12);
}

/* SECTION */

.section{
  margin-bottom:35px;
}

.section-label{
  display:flex;
  align-items:center;
  gap:10px;
  margin-bottom:18px;
}

.section-label h2{
  margin:0;
  font-size:16px;
  font-weight:700;
  color:#24324a;
  letter-spacing:0;
  text-transform:none;
}

/* DOTS */

.dot{
  width:10px;
  height:10px;
  border-radius:50%;
}

.dot-green{background:#639922;}
.dot-blue{background:#378ADD;}
.dot-amber{background:#EF9F27;}
.dot-coral{background:#D85A30;}

/* GRID */

.grid2{
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:18px;
}

.grid3{
  display:grid;
  grid-template-columns:1fr 1fr 1fr;
  gap:18px;
}

/* LABELS */

label{
  font-size:14px;
  font-weight:500;
  color:#24324a;
  display:block;
  margin-bottom:10px;
}

/* INPUTS */

input,
select,
textarea{
  width:100%;
  height:58px;
  border-radius:14px;
  border:1px solid #e5e5e5;
  padding:15px 18px;
  font-size:15px;
  font-family:'Poppins',sans-serif;
  background:#fff;
  color:#24324a;
  outline:none;
  transition:0.3s;
}

textarea{
  min-height:140px;
  resize:none;
  line-height:1.7;
}

input:focus,
select:focus,
textarea:focus{
  border-color:#cf6d86;
}

/* TAGS */

.tag-row{
  display:flex;
  flex-wrap:wrap;
  gap:12px;
  margin-top:12px;
}

.tag{
  padding:12px 18px;
  border-radius:50px;
  background:#f7f7f7;
  border:1px solid #e5e5e5;
  font-size:13px;
  cursor:pointer;
  transition:0.3s;
}

.tag.on{
  background:#cf6d86;
  color:#fff;
  border-color:#cf6d86;
}

/* META */

.meta-pill{
  margin-bottom:16px;
}

.chars{
  font-size:12px;
  color:#999;
  float:right;
}

/* DIVIDER */

.divider{
  height:1px;
  background:#f0f0f0;
  margin:35px 0;
}

/* BUTTON */

.gen-btn{
  width:100%;
  height:62px;
  border:none;
  border-radius:14px;
  background:linear-gradient(to right,#cf6d86,#df88a0);
  color:#fff;
  font-size:18px;
  font-weight:600;
  font-family:'Poppins',sans-serif;
  cursor:pointer;
  transition:0.3s;
  margin-top:10px;
}

.gen-btn:hover{
  transform:translateY(-2px);
  opacity:0.95;
}

/* OUTPUT */

.output-box{
  margin-top:25px;
  background:#fff;
  border-radius:20px;
  padding:25px;
  display:none;
  white-space:pre-wrap;
  line-height:1.8;
  box-shadow:0 10px 30px rgba(0,0,0,0.08);
}

/* SPINNER */

.spinner{
  display:inline-block;
  width:14px;
  height:14px;
  border:2px solid #fff;
  border-top-color:transparent;
  border-radius:50%;
  animation:spin 0.7s linear infinite;
  vertical-align:middle;
  margin-right:6px;
}

@keyframes spin{
  to{
    transform:rotate(360deg);
  }
}

.chatgpt-btn{
  margin-top:20px;
  width:100%;
  height:58px;
  border:none;
  border-radius:14px;
  background:#111827;
  color:#fff;
  font-size:16px;
  font-weight:600;
  font-family:'Poppins',sans-serif;
  cursor:pointer;
}

/* RESPONSIVE */

@media(max-width:991px){

  .hero-title{
    font-size:48px;
  }

  .hero-text{
    font-size:18px;
  }

  .grid2,
  .grid3{
    grid-template-columns:1fr;
  }

  .form-card{
    padding:35px;
  }
}

@media(max-width:576px){

  body{
    padding:40px 0;
  }

  .hero-title{
    font-size:34px;
  }

  .hero-text{
    font-size:16px;
  }

  .form-card{
    padding:24px;
    border-radius:24px;
  }

  .badge,
  .badge2,
  .badge3{
    font-size:12px;
    padding:10px 16px;
  }
}


/* =========================
   RESPONSIVE
========================= */

@media(max-width:991px){

  body{
    padding:50px 0;
  }

  .wrap{
    padding:0 20px;
  }

  .hero-box{
    margin-bottom:40px;
  }

  .logo-box{
    width:100px;
    height:100px;
  }

  .logo-box img{
    width:70px;
  }

  .hero-title{
    font-size:48px;
    line-height:1.15;
  }

  .hero-text{
    font-size:18px;
    line-height:1.7;
    max-width:100%;
  }

  .badge-row{
    gap:10px;
  }

  .grid2,
  .grid3{
    grid-template-columns:1fr;
    gap:16px;
  }

  .form-card{
    padding:35px;
    border-radius:28px;
  }

  .section{
    margin-bottom:28px;
  }

  .gen-btn{
    height:58px;
    font-size:16px;
  }
}

@media(max-width:767px){

  .hero-title{
    font-size:40px;
  }

  .hero-text{
    font-size:17px;
  }

  .form-card{
    padding:28px;
  }

  input,
  select,
  textarea{
    height:54px;
    font-size:14px;
    padding:14px 16px;
  }

  textarea{
    min-height:120px;
  }

  .tag{
    padding:10px 16px;
    font-size:12px;
  }
}

@media(max-width:576px){

  body{
    padding:35px 0;
  }

  .wrap{
    padding:0 14px;
  }

  .hero-box{
    margin-bottom:30px;
  }

  .logo-box{
    width:85px;
    height:85px;
    margin-bottom:20px;
  }

  .logo-box img{
    width:58px;
  }

  .hero-title{
    font-size:32px;
    line-height:1.2;
    margin-bottom:18px;
  }

  .hero-text{
    font-size:15px;
    line-height:1.7;
    margin-bottom:24px;
  }

  .badge-row{
    gap:8px;
  }

  .badge,
  .badge2,
  .badge3{
    font-size:11px;
    padding:9px 14px;
  }

  .form-card{
    padding:22px 18px;
    border-radius:22px;
  }

  .section-label{
    margin-bottom:14px;
  }

  .section-label h2{
    font-size:15px;
  }

  label{
    font-size:13px;
    margin-bottom:8px;
  }

  input,
  select,
  textarea{
    height:52px;
    border-radius:12px;
    padding:13px 14px;
    font-size:14px;
  }

  textarea{
    min-height:110px;
  }

  .tag-row{
    gap:8px;
  }

  .tag{
    padding:9px 14px;
    font-size:11px;
  }

  .divider{
    margin:28px 0;
  }

  .gen-btn{
    height:54px;
    font-size:15px;
    border-radius:12px;
  }

  .output-box{
    padding:18px;
    border-radius:16px;
    font-size:14px;
    line-height:1.7;
  }
}

@media(max-width:380px){

  .hero-title{
    font-size:28px;
  }

  .hero-text{
    font-size:14px;
  }

  .badge,
  .badge2,
  .badge3{
    width:100%;
    text-align:center;
  }

  .form-card{
    padding:18px 14px;
  }

  .gen-btn{
    font-size:14px;
  }
}





  </style>


  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>

</head>

<body>

<div class="wrap">
  <!-- <h2 class="sr-only">AI-powered blog writing tool for Indian private universities covering SEO, GEO, LLM optimization and humanized content</h2> -->
  <div class="hero-box">

  <div class="logo-box">

    <img src="images/DR logo-Transparent.png" alt="Logo">

  </div>

  <h1 class="hero-title">
    AI-Powered Blog Writing Tool <br>
    For Indian Private Universities
  </h1>

  <p class="hero-text">
    Generate SEO-ready, GEO-optimized, humanized university blogs
    designed for Google ranking, AI search visibility and LLM discoverability.
  </p>

  <div class="badge-row">

    <span class="badge">
      GEO Ready
    </span>

    <span class="badge2">
      LLM Optimized
    </span>

    <span class="badge3">
      AI-SEO
    </span>

  </div>

</div>

<div class="form-card">

  <div class="section">
    <div class="section-label"><div class="dot dot-blue"></div><h2 style="margin:0">University Profile</h2></div>
    <div class="grid2" style="margin-bottom:10px">
      <div>
        <label>University Name</label>
        <input id="uniName" placeholder="e.g. Chandigarh University" />
      </div>
      <div>
        <label>State / City</label>
        <input id="uniCity" placeholder="e.g. Punjab, Chandigarh" />
      </div>
    </div>
    <div class="grid2">
      <div>
        <label>NAAC Grade / Ranking</label>
        <input id="naac" placeholder="e.g. NAAC A++, NIRF Rank 28" />
      </div>
      <div>
        <label>Approval / Affiliation</label>
        <input id="affil" placeholder="e.g. UGC, AICTE, BCI, PCI" />
      </div>
    </div>
  </div>

  <div class="divider"></div>

  <div class="section">
    <div class="section-label"><div class="dot dot-green"></div><h2 style="margin:0">Blog Topic & Intent</h2></div>
    <div style="margin-bottom:10px">
      <label>Blog Topic / Title Idea</label>
      <input id="topic" placeholder="e.g. Top Engineering Colleges in Punjab 2025" />
    </div>
    <div class="grid2" style="margin-bottom:10px">
      <div>
        <label>Search Intent</label>
        <select id="intent">
          <option value="informational">Informational (awareness)</option>
          <option value="navigational">Navigational (find us)</option>
          <option value="transactional">Transactional (apply now)</option>
          <option value="commercial">Commercial (compare/decide)</option>
        </select>
      </div>
      <div>
        <label>Target Audience</label>
        <select id="audience">
          <option value="12th students">12th Students & Parents</option>
          <option value="graduates">Graduates seeking PG</option>
          <option value="working professionals">Working Professionals</option>
          <option value="nri students">NRI / International Students</option>
          <option value="faculty recruiters">Faculty / Recruiters</option>
        </select>
      </div>
    </div>
    <div>
      <label>Primary Focus Keyword</label>
      <input id="kw1" placeholder="e.g. best private university in Punjab" />
    </div>
    <div style="margin-top:10px">
      <label>Secondary / LSI Keywords (comma separated)</label>
      <input id="kw2" placeholder="e.g. top BCA college Punjab, NAAC A++ university India" />
    </div>
  </div>

  <div class="divider"></div>

  <div class="section">
    <div class="section-label"><div class="dot dot-amber"></div><h2 style="margin:0">SEO & GEO Settings</h2></div>
    <div class="meta-pill">
      <label>Meta Title <span class="chars" id="mtCount">0/60</span></label>
      <input id="metaTitle" placeholder="Write or leave blank for AI to generate" oninput="document.getElementById('mtCount').textContent=this.value.length+'/60'" />
    </div>
    <div class="meta-pill">
      <label>Meta Description <span class="chars" id="mdCount">0/160</span></label>
      <input id="metaDesc" placeholder="Write or leave blank for AI to generate" oninput="document.getElementById('mdCount').textContent=this.value.length+'/160'" />
    </div>
    <div class="grid2" style="margin-top:10px">
      <div>
        <label>Word Count Target</label>
        <select id="wordCount">
          <option value="800">800 words (short)</option>
          <option value="1200">1200 words (standard)</option>
          <option value="1800" selected>1800 words (in-depth)</option>
          <option value="2500">2500 words (pillar)</option>
        </select>
      </div>
      <div>
        <label>Blog Tone</label>
        <select id="tone">
          <option value="humanized, warm and conversational">Warm & Conversational</option>
          <option value="authoritative and informative">Authoritative</option>
          <option value="storytelling and narrative">Storytelling</option>
          <option value="friendly and motivational">Motivational</option>
        </select>
      </div>
    </div>
    <div style="margin-top:10px">
      <label>GEO Target Locations (for local SEO)</label>
      <input id="geo" placeholder="e.g. Mohali, Chandigarh, Ludhiana, Punjab, North India" />
    </div>
    <div style="margin-top:10px">
      <label>Schema Markup Type</label>
      <div class="tag-row" id="schemaTags">
        <span class="tag on" onclick="toggleTag(this)">Article</span>
        <span class="tag" onclick="toggleTag(this)">FAQPage</span>
        <span class="tag" onclick="toggleTag(this)">BreadcrumbList</span>
        <span class="tag" onclick="toggleTag(this)">EducationalOrganization</span>
        <span class="tag" onclick="toggleTag(this)">HowTo</span>
        <span class="tag" onclick="toggleTag(this)">LocalBusiness</span>
      </div>
    </div>
  </div>

  <div class="divider"></div>

  <div class="section">
    <div class="section-label"><div class="dot dot-coral"></div><h2 style="margin:0">LLM & AI-SEO Optimization</h2></div>
    <div style="margin-bottom:10px">
      <label>Key Unique Selling Points (USPs) of the University</label>
      <textarea id="usps" placeholder="e.g. 500+ industry partnerships, 95% placement rate, 200-acre campus, 15,000 students, international exchange programs..."></textarea>
    </div>
    <div style="margin-bottom:10px">
      <label>Programs / Courses to Highlight</label>
      <input id="programs" placeholder="e.g. B.Tech CSE, MBA, BBA, Law, Pharmacy, B.Arch" />
    </div>
    <div>
      <label>Competitor Differentiators (what sets this university apart?)</label>
      <textarea id="diff" placeholder="e.g. Ranked #1 in Punjab by India Today, lower fee than DU, hostels for girls with 24x7 security..." style="min-height:60px"></textarea>
    </div>
    <div style="margin-top:10px">
      <label>Featured Snippet / People Also Ask Topics</label>
      <input id="paa" placeholder="e.g. Is Chandigarh University private or government? What is the fee structure?" />
    </div>
    <div style="margin-top:10px">
      <label>Internal Links to Include</label>
      <input id="links" placeholder="e.g. /admissions, /fee-structure, /placements, /hostel" />
    </div>
    <div style="margin-top:10px">
      <label>Special Instructions for the Writer</label>
      <textarea id="special" placeholder="e.g. Don't mention specific fee amounts, include a CTA at the end for counselling, avoid competitor names..." style="min-height:60px"></textarea>
    </div>
  </div>


  </div>
 

<button type="button" class="gen-btn" onclick="saveAndShowData()">
  Submit Form
</button>

  <div class="output-box" id="output"></div>
  <div class="saved-data-box" id="savedDataBox"></div>
</div>


<script>
function toggleTag(el) {
    document.querySelectorAll('#schemaTags .tag').forEach(function(tag) {
        tag.classList.remove('on');
    });

    el.classList.add('on');
}

async function saveAndShowData() {
    const btn = document.querySelector('.gen-btn');
    const output = document.getElementById('output');

    const fields = {
        user_name: "<?php echo addslashes($userName); ?>",
        university_name: document.getElementById('uniName').value,
        university_city: document.getElementById('uniCity').value,
        naac: document.getElementById('naac').value,
        affiliation: document.getElementById('affil').value,
        topic: document.getElementById('topic').value,
        intent: document.getElementById('intent').value,
        audience: document.getElementById('audience').value,
        keyword1: document.getElementById('kw1').value,
        keyword2: document.getElementById('kw2').value,
        meta_title: document.getElementById('metaTitle').value,
        meta_description: document.getElementById('metaDesc').value,
        word_count: document.getElementById('wordCount').value,
        tone: document.getElementById('tone').value,
        geo_targets: document.getElementById('geo').value,
        schema_types: document.querySelector('#schemaTags .tag.on')?.innerText || '',
        usps: document.getElementById('usps').value,
        programs: document.getElementById('programs').value,
        differentiators: document.getElementById('diff').value,
        paa: document.getElementById('paa').value,
        internal_links: document.getElementById('links').value,
        special_instructions: document.getElementById('special').value,
        ai_response: ''
    };

    

    const formData = new FormData();

    for (let key in fields) {
        formData.append(key, fields[key]);
    }

    btn.disabled = true;
    btn.innerHTML = "Saving...";

    try {
        const response = await fetch('save_blog.php', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();

        if (result.status === 'success') {
            output.style.display = "block";
            output.innerHTML = "<strong>Success!</strong> Data saved successfully.";
            output.className = "output-box alert alert-success";

            showSavedData(result.data);
        } else {
            throw new Error(result.message || "Data not saved.");
        }

    } catch (error) {
        output.style.display = "block";
        output.innerHTML = "<strong>Error:</strong> " + error.message;
        output.className = "output-box alert alert-danger";
    }

    btn.disabled = false;
    btn.innerHTML = "Submit Form";
}

let savedDBData = {};

function showSavedData(data) {

    savedDBData = data;

    const box = document.getElementById('savedDataBox');

    box.style.display = "block";

    box.innerHTML = `
      <h2>Saved Blog Request Summary</h2>

      <p><strong>University Profile:</strong> ${data.university_name || 'N/A'} is located in ${data.university_city || 'N/A'}. Its NAAC / ranking detail is ${data.naac || 'N/A'}, and approval / affiliation detail is ${data.affiliation || 'N/A'}.</p>

      <p><strong>Blog Topic & Intent:</strong> The selected blog topic is "${data.topic || 'N/A'}". The search intent is ${data.intent || 'N/A'}, and the target audience is ${data.audience || 'N/A'}.</p>

      <p><strong>Keywords:</strong> Primary keyword is "${data.keyword1 || 'N/A'}". Secondary / LSI keywords are "${data.keyword2 || 'N/A'}".</p>

      <p><strong>SEO Settings:</strong> Meta title is "${data.meta_title || 'N/A'}". Meta description is "${data.meta_description || 'N/A'}". Target word count is ${data.word_count || 'N/A'} with a ${data.tone || 'N/A'} tone.</p>

      <p><strong>GEO & Schema:</strong> GEO target locations are ${data.geo_targets || 'N/A'}, and selected schema type is ${data.schema_types || 'N/A'}.</p>

      <p><strong>LLM / AI SEO Inputs:</strong> Key USPs include ${data.usps || 'N/A'}. Programs to highlight are ${data.programs || 'N/A'}. Differentiators are ${data.differentiators || 'N/A'}.</p>

      <p><strong>PAA & Internal Links:</strong> People Also Ask topics are ${data.paa || 'N/A'}. Internal links to include are ${data.internal_links || 'N/A'}.</p>

      <p><strong>Special Instructions:</strong> ${data.special_instructions || 'N/A'}</p>

      <p><strong>Created At:</strong> ${data.created_at || 'N/A'}</p>

      <button 
      type="button" 
      class="chatgpt-btn"
      onclick="generateClaudeBlogFromSavedData()"
      >
      Generate Blog with Claude AI
      </button>

      <div id="claudeBlogOutput" style="
      margin-top:25px;
      background:#fff7fa;
      padding:25px;
      border-radius:18px;
      line-height:1.9;
      font-size:15px;
      color:#444;
      display:none;
      "></div>
    `;
}


async function generateClaudeBlogFromSavedData() {
    const output = document.getElementById('claudeBlogOutput');

    output.style.display = "block";
    output.innerHTML = "Sending saved data to Claude AI...";

    const formData = new FormData();

    for (let key in savedDBData) {
        formData.append(key, savedDBData[key]);
    }

    try {
        const response = await fetch('generate_blog.php', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();

        if (result.status === 'success') {
            output.innerHTML = result.blog;
        } else {
            output.innerHTML = `<strong style="color:red;">${result.message}</strong>`;
        }

    } catch (error) {
        output.innerHTML = `<strong style="color:red;">${error.message}</strong>`;
    }
}
</script>


</body>

</html>