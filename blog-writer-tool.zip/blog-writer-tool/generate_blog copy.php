<?php

header('Content-Type: application/json');

$data = $_POST;

$prompt = "

You are an expert SEO and GEO blog writer.

Write a fully humanized university blog using the following details:

University Name: {$data['university_name']}
Location: {$data['university_city']}
NAAC / Ranking: {$data['naac']}
Affiliation: {$data['affiliation']}

Blog Topic: {$data['topic']}
Search Intent: {$data['intent']}
Audience: {$data['audience']}

Primary Keyword: {$data['keyword1']}
Secondary Keywords: {$data['keyword2']}

Meta Title: {$data['meta_title']}
Meta Description: {$data['meta_description']}

Word Count: {$data['word_count']}
Tone: {$data['tone']}

GEO Targets: {$data['geo_targets']}
Schema Type: {$data['schema_types']}

USPs:
{$data['usps']}

Programs:
{$data['programs']}

Differentiators:
{$data['differentiators']}

PAA Topics:
{$data['paa']}

Internal Links:
{$data['internal_links']}

Special Instructions:
{$data['special_instructions']}

Requirements:
- Extremely humanized
- SEO optimized
- GEO optimized
- No robotic tone
- Use engaging headings
- Include FAQ section
- Optimized for AI search engines
- Avoid AI detectable writing
";

$apiKey = "YOUR_CLAUDE_API_KEY";

$payload = [
    "model" => "claude-sonnet-4-20250514",
    "max_tokens" => 4000,
    "messages" => [
        [
            "role" => "user",
            "content" => $prompt
        ]
    ]
];

$ch = curl_init("https://api.anthropic.com/v1/messages");

curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);

curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "x-api-key: $apiKey",
    "anthropic-version: 2023-06-01"
]);

curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));

$response = curl_exec($ch);

curl_close($ch);

echo $response;
?>