<?php
header('Content-Type: application/json');

// Database configuration
$host = 'localhost';
$db   = 'university_blog_writer';
$user = 'root';
$pass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Prepare SQL based on image_e09ad9.png columns
    $sql = "INSERT INTO blog_requests (
        university_name, university_city, naac, affiliation, topic, 
        intent, audience, keyword1, keyword2, meta_title, 
        meta_description, word_count, tone, geo_targets, schema_types, 
        usps, programs, differentiators, paa, internal_links, 
        special_instructions
    ) VALUES (
        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
    )";

    $stmt = $pdo->prepare($sql);
    
    $stmt->execute([
        $_POST['university_name'] ?? '',
        $_POST['university_city'] ?? '',
        $_POST['naac'] ?? '',
        $_POST['affiliation'] ?? '',
        $_POST['topic'] ?? '',
        $_POST['intent'] ?? '',
        $_POST['audience'] ?? '',
        $_POST['keyword1'] ?? '',
        $_POST['keyword2'] ?? '',
        $_POST['meta_title'] ?? '',
        $_POST['meta_description'] ?? '',
        $_POST['word_count'] ?? '',
        $_POST['tone'] ?? '',
        $_POST['geo_targets'] ?? '',
        $_POST['schema_types'] ?? '',
        $_POST['usps'] ?? '',
        $_POST['programs'] ?? '',
        $_POST['differentiators'] ?? '',
        $_POST['paa'] ?? '',
        $_POST['internal_links'] ?? '',
        $_POST['special_instructions'] ?? ''
    ]);

    echo json_encode([
        'status' => 'success', 
        'id' => $pdo->lastInsertId(),
        'message' => 'Data stored successfully'
    ]);

} catch (PDOException $e) {
    echo json_encode([
        'status' => 'error', 
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>