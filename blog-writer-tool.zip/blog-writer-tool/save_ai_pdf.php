<?php

include 'dr-admin/config.php';

if(!isset($_POST['id']) || !isset($_POST['pdf_data'])){
    echo "missing data";
    exit;
}

$id = intval($_POST['id']);
$pdfData = $_POST['pdf_data'];

if(strpos($pdfData, ',') !== false){
    $pdfData = explode(',', $pdfData)[1];
}

$pdfData = str_replace(' ', '+', $pdfData);

$pdfContent = base64_decode($pdfData);

if($pdfContent === false || strlen($pdfContent) < 100){
    echo "invalid pdf data";
    exit;
}

$folder = "generated-pdfs/";

if(!is_dir($folder)){
    mkdir($folder, 0777, true);
}

$fileName = "ai_blog_report_" . $id . "_" . time() . ".pdf";
$filePath = $folder . $fileName;

file_put_contents($filePath, $pdfContent);

$filePathSafe = mysqli_real_escape_string($conn, $filePath);

$update = mysqli_query(
    $conn,
    "UPDATE blog_requests
     SET pdf_file='$filePathSafe'
     WHERE id='$id'"
);

if($update){
    echo "success";
}else{
    echo "failed: " . mysqli_error($conn);
}

?>