<?php

include 'dr-admin/config.php';

if(!isset($_POST['id']) || !isset($_POST['ai_outcome'])){
    echo "missing data";
    exit;
}

$id = intval($_POST['id']);
$aiOutcome = mysqli_real_escape_string($conn, $_POST['ai_outcome']);

$update = mysqli_query(
    $conn,
    "UPDATE blog_requests
     SET ai_response = '$aiOutcome'
     WHERE id = '$id'"
);

if($update){
    echo "success";
}else{
    echo "failed: " . mysqli_error($conn);
}

?>