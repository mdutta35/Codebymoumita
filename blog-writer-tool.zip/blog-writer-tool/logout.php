<?php
session_start();

include 'dr-admin/config.php';

if(isset($_SESSION['login_history_id']) && isset($_SESSION['login_time'])){

    $logoutTime = date("Y-m-d H:i:s");

    $loginTime = strtotime($_SESSION['login_time']);
    $logoutTimestamp = strtotime($logoutTime);

    $duration = $logoutTimestamp - $loginTime;

    $historyId = intval($_SESSION['login_history_id']);

    mysqli_query(
        $conn,
        "UPDATE blog_writer_user_login_history
        SET
        logout_time='$logoutTime',
        duration_seconds='$duration'
        WHERE id='$historyId'"
    );
}

session_destroy();

header("Location: login.php");
exit;
?>