<?php
session_start();

/* =========================
   LOGIN CHECK
========================= */

if(!isset($_SESSION['user_id'])){

    header("Location: login.php");
    exit;
}

$userName = $_SESSION['user_name'];
?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="UTF-8">

  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>Dashboard</title>

  <!-- Poppins Font -->

  <link rel="preconnect" href="https://fonts.googleapis.com">

  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

  <link
    href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap"
    rel="stylesheet"
  >

  <!-- Bootstrap Icons -->

  <link
    rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
  >

  <style>

    *{
      margin:0;
      padding:0;
      box-sizing:border-box;
    }

    body{
      font-family:'Poppins',sans-serif;
      background:linear-gradient(135deg,#c96b86,#df88a0);
      min-height:100vh;
      overflow-x:hidden;
      position:relative;
      padding:40px 0;
    }

    /* BACKGROUND */

    body::before{
      content:"";
      position:absolute;
      width:700px;
      height:700px;
      background:rgba(255,255,255,0.08);
      border-radius:50%;
      top:-250px;
      left:-200px;
    }

    body::after{
      content:"";
      position:absolute;
      width:800px;
      height:800px;
      background:rgba(255,255,255,0.05);
      border-radius:50%;
      bottom:-350px;
      right:-250px;
    }

    /* WRAP */

    .wrap{
      width:100%;
      max-width:1250px;
      margin:auto;
      padding:0 20px;
      position:relative;
      z-index:2;
    }

    /* TOPBAR */

    .topbar{
      display:flex;
      justify-content:flex-end;
      margin-bottom:25px;
    }

    /* PROFILE */

    .profile-dropdown{
      position:relative;
    }

    .profile-btn{
      width:54px;
      height:54px;
      border:none;
      border-radius:50%;
      background:#fff;
      color:#cf6d86;
      font-size:18px;
      font-weight:700;
      cursor:pointer;
      box-shadow:0 10px 30px rgba(0,0,0,0.12);
      transition:0.3s;
    }

    .profile-btn:hover{
      transform:translateY(-2px);
    }

    .profile-menu{
      position:absolute;
      top:65px;
      right:0;
      width:190px;
      background:#fff;
      border-radius:18px;
      padding:10px;
      box-shadow:0 20px 50px rgba(0,0,0,0.12);
      display:none;
      z-index: 10;
    }

    .profile-menu.show{
      display:block;
    }

    .profile-menu a{
      display:flex;
      align-items:center;
      gap:10px;
      padding:13px 14px;
      border-radius:12px;
      text-decoration:none;
      color:#24324a;
      font-size:14px;
      font-weight:500;
      transition:0.3s;
    }

    .profile-menu a:hover{
      background:#f7f7f7;
      color:#cf6d86;
    }

    /* HERO */

    .hero-banner{
      background:rgba(255,255,255,0.12);
      border:1px solid rgba(255,255,255,0.15);
      backdrop-filter:blur(10px);
      border-radius:35px;
      padding:70px 50px;
      text-align:center;
      color:#fff;
      margin-bottom:45px;
    }

    .hero-banner h1{
      font-size:60px;
      font-weight:800;
      margin-bottom:15px;
    }

    .hero-banner p{
      font-size:18px;
      line-height:1.7;
      max-width:700px;
      margin:auto;
      color:rgba(255,255,255,0.92);
    }

    /* SECTION TITLE */

    .section-title{
      font-size:32px;
      font-weight:700;
      color:#fff;
      margin-bottom:30px;
    }

    /* GRID */

    .prompt-grid{
      display:grid;
      grid-template-columns:repeat(3,1fr);
      gap:24px;
    }

    /* BOX */

    .prompt-box{
      background:rgba(255,255,255,0.96);
      border-radius:28px;
      padding:35px 28px;
      transition:0.3s;
      cursor:pointer;
      box-shadow:0 15px 40px rgba(0,0,0,0.1);
    }

    .prompt-box:hover{
      transform:translateY(-5px);
    }

    /* ICON */

    .prompt-icon{
      width:68px;
      height:68px;
      border-radius:20px;
      background:linear-gradient(to right,#cf6d86,#df88a0);
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:28px;
      color:#fff;
      margin-bottom:20px;
    }

    /* TEXT */

    .prompt-box h3{
      font-size:22px;
      font-weight:700;
      color:#24324a;
      margin-bottom:12px;
    }

    .prompt-box p{
      font-size:14px;
      line-height:1.7;
      color:#666;
    }

    /* RESPONSIVE */

    @media(max-width:991px){

      .hero-banner{
        padding:50px 30px;
      }

      .hero-banner h1{
        font-size:44px;
      }

      .prompt-grid{
        grid-template-columns:1fr 1fr;
      }
    }

    @media(max-width:576px){

      body{
        padding:20px 0;
      }

      .wrap{
        padding:0 14px;
      }

      .hero-banner{
        padding:40px 20px;
        border-radius:24px;
      }

      .hero-banner h1{
        font-size:34px;
      }

      .hero-banner p{
        font-size:15px;
      }

      .section-title{
        font-size:24px;
        margin-bottom:20px;
      }

      .prompt-grid{
        grid-template-columns:1fr;
        gap:18px;
      }

      .prompt-box{
        padding:28px 22px;
        border-radius:22px;
      }

      .prompt-box h3{
        font-size:20px;
      }
    }


    .prompt-link{
    display: inline-flex;
    align-items: center;
    gap: 8px;
    margin-top: 18px;
    color: #facc15;
    font-size: 0.95rem;
    font-weight: 600;
    text-decoration: none;
    transition: all 0.3s ease;
}

.prompt-link i{
    transition: transform 0.3s ease;
}

.prompt-link:hover{
    color: black;
}

.prompt-link:hover i{
    transform: translateX(4px);
}

  </style>

</head>

<body>

  <div class="wrap">

    <!-- TOPBAR -->

    <div class="topbar">

      <div class="profile-dropdown">

        <button class="profile-btn" onclick="toggleProfileMenu()">

          <?php echo strtoupper(substr($userName,0,1)); ?>

        </button>

        <div class="profile-menu" id="profileMenu">

          <a href="logout.php">

            <i class="bi bi-box-arrow-right"></i>

            Logout

          </a>

        </div>

      </div>

    </div>

    <!-- HERO -->

    <div class="hero-banner">

      <h1>
        Welcome, <?php echo $userName; ?>
      </h1>

      <p>
        Access AI-powered university marketing prompts,
        SEO content tools and blog generation workflows.
      </p>

    </div>

    <!-- SECTION TITLE -->

    <h2 class="section-title">
      Choose Your Prompt
    </h2>

    <!-- PROMPT GRID -->

    <div class="prompt-grid">

      <!-- BOX 1 -->
<div class="prompt-box">

    <div class="prompt-icon">
        <i class="bi bi-pencil-square"></i>
    </div>

    <h3>
        AI-Powered Blog Writing Tool
    </h3>

    <p>
        Generate SEO-ready, GEO-optimized, humanized university blogs designed for Google ranking, AI search visibility and LLM discoverability.
    </p>

    <a href="prompt-one.php" class="prompt-link">
        Explore More <i class="bi bi-arrow-right"></i>
    </a>

</div>

<!-- BOX 2 -->
<div class="prompt-box">

    <div class="prompt-icon">
        <i class="bi bi-mortarboard"></i>
    </div>

    <h3>
        Admission Campaign
    </h3>

    <p>
        Create admission focused marketing content.
    </p>

    <a href="#" class="prompt-link">
        Explore More <i class="bi bi-arrow-right"></i>
    </a>

</div>

<!-- BOX 3 -->
<div class="prompt-box">

    <div class="prompt-icon">
        <i class="bi bi-graph-up-arrow"></i>
    </div>

    <h3>
        SEO Content
    </h3>

    <p>
        Generate high ranking SEO optimized articles.
    </p>

    <a href="#" class="prompt-link">
        Explore More <i class="bi bi-arrow-right"></i>
    </a>

</div>

<!-- BOX 4 -->
<div class="prompt-box">

    <div class="prompt-icon">
        <i class="bi bi-robot"></i>
    </div>

    <h3>
        GEO + LLM
    </h3>

    <p>
        AI discoverability optimized university content.
    </p>

    <a href="#" class="prompt-link">
        Explore More <i class="bi bi-arrow-right"></i>
    </a>

</div>

<!-- BOX 5 -->
<div class="prompt-box">

    <div class="prompt-icon">
        <i class="bi bi-megaphone"></i>
    </div>

    <h3>
        Social Media
    </h3>

    <p>
        Create engaging social media campaign copies.
    </p>

    <a href="#" class="prompt-link">
        Explore More <i class="bi bi-arrow-right"></i>
    </a>

</div>

<!-- BOX 6 -->
<div class="prompt-box">

    <div class="prompt-icon">
        <i class="bi bi-award"></i>
    </div>

    <h3>
        Brand Positioning
    </h3>

    <p>
        Build strong university brand messaging.
    </p>

    <a href="#" class="prompt-link">
        Explore More <i class="bi bi-arrow-right"></i>
    </a>

</div>

    </div>

  </div>

  <!-- JS -->

  <script>

    function toggleProfileMenu(){

      document
        .getElementById("profileMenu")
        .classList.toggle("show");
    }

    window.onclick=function(e){

      if(!e.target.closest('.profile-dropdown')){

        document
          .getElementById("profileMenu")
          .classList.remove("show");
      }
    }

  </script>

</body>

</html>